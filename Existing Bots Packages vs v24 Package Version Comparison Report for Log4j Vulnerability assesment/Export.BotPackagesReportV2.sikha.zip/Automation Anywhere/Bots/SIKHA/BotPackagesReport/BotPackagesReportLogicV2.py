# Author: Sikha Poyyil
#         Global Solution Desk(GSD)
# Company: Automation Anywhere

#The following modules are needed for this script:
#json (Built-in)
#inspect (Built-in)
#logging (Built-in)
#requests (External)
# Note: Below external libraries to be installed for script to work.
# pip install requests

import json
import inspect
import logging
import requests

# Global variables defined
logger = logging.getLogger(__name__)
updates_json = None


# Log the messages using logging library
def log(log_msg, log_level):
    # Automatically log the current function details.
    # Get the previous frame in the stack, otherwise it would be this function!!!
    func = inspect.currentframe().f_back.f_code

    # Dump the message + the name of this function to the log.
    logger.log(level=getattr(logging, log_level.upper(), None), msg='{0}): {1}'.format(func.co_name, log_msg))


# Initializing a logger with custom configuration
def initialize_logger(log_file_path, log_level):
    logger.setLevel(getattr(logging, log_level.upper()))
    file_handler = logging.FileHandler(log_file_path, mode='a')
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(name)s (%(message)s', datefmt='(%d-%m-%Y %I.%M.%S %p)')

    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    log("Log file started.", 'info')


def compare_versions(args):
    version1 = args[0]
    version2 = args[1]
    v1 = list(map(int, version1.split('.')))
    v2 = list(map(int, version2.split('.')))
    if v1 > v2:
        return "No"
    elif v1 < v2:
        return "Yes"
    else:
        return "No"

    # Get user token status - valid or invalid


def token_status(cr_url, user_token):
    headers = {"accept": "application/json"}

    log("Token status: no data", 'debug')
    log("Headers: " + str(headers), 'debug')
    log("URL: " + cr_url + '/v1/authentication/token?token=' + str(user_token)[0:20], 'debug')

    response = requests.get(cr_url + '/v1/authentication/token?token=' + user_token, headers=headers)

    # Checking if response status is 200
    if response.status_code == 200:
        json_obj = response.json()
        log('Token status: ' + str(json_obj.get('valid')), 'info')
        # print('Token status: ' + str(json_obj.get('valid')))
        return str(json_obj.get('valid'))

    else:
        # Returning error json object
        error_json_obj = response.json()
        log(error_json_obj, 'info')
        # print(str(error_json_obj))
        return error_json_obj


def refresh_token(cr_url, user_token):
    """
    Function to get a new token if the current one expires.
    Modify this to match your actual token refresh API.
    """
    refresh_url = cr_url+"/v2/authentication/token"  # Update this URL
    headers = {"X-Authorization": user_token, 'Content-type': 'application/json', 'Accept': 'text/plain'}
    response = requests.post(refresh_url, headers=headers)

    if response.status_code == 200:
        new_token = response.json().get("token")
        return new_token
    else:
        raise Exception(f"Error: Failed to refresh token: {response.status_code} - {response.text}")


# Generate user token in A360 Control room
def generate_token(cr_url, username, password, api_key):
    if password == '' and api_key.strip() != '':
        # Api key is not null and password is null
        data = '{ \"username\": \"' + str(username) + '\", \"apiKey\": \"' + str(api_key) + '\"}'
        log("Generate token: data = " + '{ \"username\": \"*********\", \"apiKey\": \"*********\"}', 'debug')

    elif password != '' and api_key.strip() == '':
        # Password is not null and api key is null
        data = '{ \"username\": \"' + str(username) + '\", \"password\": \"' + str(password) + '\"}'
        log("Generate token: data = " + '{ \"username\": \"*********\", \"password\": \"*********\"}', 'debug')

    elif password != '' and api_key.strip() != '':
        # Password and api key both are not null
        data = '{ \"username\": \"' + str(username) + '\", \"apiKey\": \"' + str(api_key) + '\"}'
        log("Generate token: data = " + '{ \"username\": \"*********\", \"apiKey\": \"*********\"}', 'debug')

    else:
        # Password and api key both are null
        result = json.dumps({'code': 'user.credentials.empty', 'details': '',
                             'message': 'Both password and api key are null. Please provide either one of them to generate user token'})
        log(result, 'info')
        return result

    headers = {'Content-type': 'application/json', 'Accept': 'application/json'}

    log("Headers: " + str(headers), 'debug')
    log("URL: " + cr_url + '/v2/authentication', 'debug')

    response = requests.post(cr_url + '/v2/authentication', data=data, headers=headers)

    # Checking if response status is 200
    if response.status_code == 200:
        json_obj = response.json()

        # print("User Token: " + str(json_obj.get('token'))[0:20] + ".******")
        log("User Token: " + str(json_obj.get('token'))[0:20] + ".****** generated.", 'info')
        # Returning user token
        return json_obj.get('token')
    else:
        error_json_obj = response.json()

        # print(str(error_json_obj))
        # Returning error json object
        log(str(error_json_obj), 'info')
        return error_json_obj


def getAllTaskBotsByFolderID(args):
    folder_ids = args[0]
    cr_url = args[1]
    token = args[2]
    inputoutputFolderPath = args[3]
    log_file_path = inputoutputFolderPath + "\\botPackagesReportLogs.log"

    log_level = 'debug'
    initialize_logger(log_file_path=log_file_path, log_level=log_level)
    log("getAllTaskBotsByFolderID", log_level)

    return get_files_from_folder(folder_ids, cr_url, token, log_level)


def get_files_from_folderOLD(folder_id, cr_url, token, log_level):
    headers = {
        "X-Authorization": str(token)
    }

    all_files = []

    def fetch_filesOLD(folder_id):
        page_number = 0

        while True:
            payload = {
                "filter": {},
                "sort": [{"field": "id", "direction": "desc"}],
                "page": {
                    "offset": page_number * 100,
                    "length": 100
                }
            }

            # API Call
            response = requests.post(f"{cr_url}/v2/repository/folders/{folder_id}/list", headers=headers, json=payload)

            if response.status_code != 200:
                log(f"Error fetching folder contents: {response.status_code} - {response.text}", log_level)
                return

            data = response.json()
            items = data.get('list', [])

            if not items:
                break  # Stop if no more items to fetch

            for item in items:
                if item['type'] == 'application/vnd.aa.taskbot':
                    all_files.append(item)
                elif item['type'] == 'application/vnd.aa.directory':
                    fetch_filesOLD(item['id'])  # Recursively fetch subfolder contents

            page_number += 1  # Move to the next page for pagination

    fetch_filesOLD(folder_id)
    formatted_json = json.dumps({"list": all_files}, indent=4)
    return formatted_json


def get_files_from_folder(folder_ids, cr_url, token, log_level):
    log("inside get_files_from_folder", log_level)
    headers = {"X-Authorization": str(token)}

    all_files = []  # Store full TaskBot details
    seen_items = set()  # Track IDs to prevent duplicates
    processed_subfolders = set()  # Track processed subfolders
    token_refreshed = False  # Track if token was refreshed

    def fetch_files(folder_id):
        nonlocal token, headers, token_refreshed
        page_number = 0

        try:
            while True:
                payload = {
                    "filter": {},
                    "sort": [{"field": "id", "direction": "desc"}],
                    "page": {
                        "offset": page_number * 100,
                        "length": 100
                    }
                }

                response = requests.post(f"{cr_url}/v2/repository/folders/{folder_id}/list", headers=headers,
                                         json=payload)
                log(response.status_code, log_level)
                # Handle unauthorized (401) error and refresh token
                if response.status_code == 401 and not token_refreshed:
                    log("Token expired, refreshing..." + folder_id, log_level)
                    try:
                        token = refresh_token(cr_url, token)  # Get a new token
                        headers["X-Authorization"] = str(token)  # Update headers
                        token_refreshed = True  # Prevent multiple refresh attempts
                        return fetch_files(folder_id)  # Retry the request
                    except Exception as e:
                        log(f"Error: Token refresh failed: {str(e)} {folder_id}", log_level)
                        return

                # Handle other errors
                if response.status_code != 200:
                    log(f"Error: fetching folder contents: {response.status_code} - {response.text}", log_level)
                    return

                data = response.json()
                items = data.get('list', [])

                # Stop pagination if no new items are received
                new_items = [item for item in items if item['id'] not in seen_items]
                if not new_items:
                    break

                for item in new_items:
                    seen_items.add(item['id'])  # Track item ID to avoid duplication

                    if item['type'] == 'application/vnd.aa.taskbot':
                        all_files.append(item)  # Store full item details
                    elif item['type'] == 'application/vnd.aa.directory' and item['id'] not in processed_subfolders:
                        processed_subfolders.add(item['id'])  # Mark subfolder as processed
                        fetch_files(item['id'])  # Recursively fetch subfolder contents

                page_number += 1  # Move to the next page for pagination

        except requests.exceptions.RequestException as e:
            log(f"Error: Request failed: {str(e)}", log_level)
        except Exception as e:
            log(f"Unexpected Error: {str(e)}", log_level)

    try:
        folder_id_list = folder_ids.split(',')  # Split input into a list of folder IDs
        for folder_id in folder_id_list:
            folder_id = folder_id.strip()  # Remove any spaces
            log("Processing folder: " + folder_id, log_level)
            fetch_files(folder_id)

        formatted_json = json.dumps({"list": all_files}, indent=4)
        return formatted_json
    except Exception as e:
        log(f"Critical error in fetching files: {str(e)}", log_level)
        return json.dumps({"Error": "Failed to retrieve files"})



# getAllTaskBotsByFolderID(["20971", "https://aa-pet-us-17.my.automationanywhere.digital",
#                           "eyJhbGciOiJSUzUxMiJ9.eyJzdWIiOiIyMzciLCJjbGllbnwMDJhYyIsIm11bHRpcGxlTG9naW4iOmZhbHNlLCJpYXQiOjE3NDE2ODg0MzUsImV4cCI6MTc0MTY4OTYzNSwiaXNzIjoiQXV0b21hdGlvbkFueXdoZXJlIiwibmFub1RpbWUiOjIyNzU3MzM3NjU3MTE4OTR9.mya8kN2l1RxeXweni4lVYpR03p3mvQcCVp95QfUIAmqYYweqWJ5UNhXDe_VIbn6HALhVi2ZxWwS-_YyGPNx-t2CsQjoJrrPIreokMBHR_jqWcHgN7gEZNXQLhklKLt_Iqa1w8TsZsqZhD5KkzjQTaQDB1--heeeEtgIxbCR6FcfwUTj2BFJPYdjmrvm9_KRoO8-NKK5E_pbcjajfwxV4kx2DTQwYSrJV1RCAVH65Yhdhx6aH15KLOi2M9cdgIylMhLsviyAQT-8ooyw-atdKR5zRYfuQnOB39Mq3rTekJAhZIzleEhUuZAZp3dkarBl3ZI7_GHa4VP9i2vL9w8zV0A",
#                           "C:\\Users\\Sikha.P\\PycharmProjects\\inputFolder"])
