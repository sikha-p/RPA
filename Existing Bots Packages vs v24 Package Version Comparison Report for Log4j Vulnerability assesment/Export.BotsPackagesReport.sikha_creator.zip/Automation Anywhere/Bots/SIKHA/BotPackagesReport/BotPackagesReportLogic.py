# Author: Sikha Poyyil
#         Global Solution Desk(GSD)
# Company: Automation Anywhere

#The following modules are needed for this script:
#json (Built-in)
#inspect (Built-in)
#logging (Built-in)
#requests (External)
# Note: Below external libraries to be installed for script to work.
# pip install requests
import json
import inspect
import logging
import requests

# Global variables defined
logger = logging.getLogger(__name__)
updates_json = None


# Log the messages using logging library
def log(log_msg, log_level):
    # Automatically log the current function details.
    # Get the previous frame in the stack, otherwise it would be this function!!!
    func = inspect.currentframe().f_back.f_code

    # Dump the message + the name of this function to the log.
    logger.log(level=getattr(logging, log_level.upper(), None), msg='{0}): {1}'.format(func.co_name, log_msg))


# Initializing a logger with custom configuration
def initialize_logger(log_file_path, log_level):
    logger.setLevel(getattr(logging, log_level.upper()))
    file_handler = logging.FileHandler(log_file_path, mode='a')
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(name)s (%(message)s', datefmt='(%d-%m-%Y %I.%M.%S %p)')

    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    log("Log file started.", 'info')


def getAllTaskBotsByFolderID(args):
    folder_id = args[0]
    cr_url = args[1]
    token = args[2]
    inputoutputFolderPath = args[3]
    log_file_path = inputoutputFolderPath + "\\botPackagesReportLogs.log"

    log_level = 'debug'
    initialize_logger(log_file_path=log_file_path, log_level=log_level)
    log("getAllTaskBotsByFolderID", log_level)

    return get_files_from_folder(folder_id, cr_url, token, log_level)


def get_files_from_folder(folder_id, cr_url, token, log_level):
    headers = {
        "X-Authorization": str(token)
    }

    all_files = []  # Store full TaskBot details
    seen_items = set()  # Track IDs to prevent duplicates
    processed_subfolders = set()  # Track processed subfolders

    def fetch_files(folder_id):
        page_number = 0

        while True:
            payload = {
                "filter": {},
                "sort": [{"field": "id", "direction": "desc"}],
                "page": {
                    "offset": page_number * 100,
                    "length": 100
                }
            }

            response = requests.post(f"{cr_url}/v2/repository/folders/{folder_id}/list", headers=headers, json=payload)

            if response.status_code != 200:
                log(f"Error fetching folder contents: {response.status_code} - {response.text}", log_level)
                return

            data = response.json()
            items = data.get('list', [])

            # Stop pagination if no new items are received
            new_items = [item for item in items if item['id'] not in seen_items]
            if not new_items:
                break

            for item in new_items:
                seen_items.add(item['id'])  # Track item ID to avoid duplication

                if item['type'] == 'application/vnd.aa.taskbot':
                    all_files.append(item)  # Store full item details
                elif item['type'] == 'application/vnd.aa.directory' and item['id'] not in processed_subfolders:
                    processed_subfolders.add(item['id'])  # Mark subfolder as processed
                    fetch_files(item['id'])  # Recursively fetch subfolder contents

            page_number += 1  # Move to the next page for pagination

    fetch_files(folder_id)
    formatted_json = json.dumps({"list": all_files}, indent=4)
    return formatted_json

# getAllTaskBotsByFolderID(["20971",
#                           "https://aa-pet-us-17.my.automationanywhere.digital",
#                           "eyJhbGciOiJSUzUxMiJ9.eyJzdWIiOiIyMzciLCJjbGllbnRUeXBlIjoiV0VCIiwidGVuYW50VXVpZCI6IjBhNjY1YzQ2LTc4ZWUtMTI2NC04MTc5LWE1MzI5NjMwMDJhYyIsIm11bHRpcGxlTG9naW4iOmZhbHNlLCJpYXQiOjE3NDEyMzY4NDEsImV4cCI6MTc0MTIzODA0MSwiaXNzIjoiQXV0b21hdGlvbkFueXdoZXJlIiwibmFub1RpbWUiOjE4MjQxMzk4MzUxOTk0ODB9.iO4BcPJcaKkTXhz8vyW-8l6Ry_y1CuADmtu49dYnrTO5cAmlowVP5oQz8CkviGU_p7OEOji6x55ESCy3dFFn05jhAQwCzISFb3lgcdGLRTOYk9xkD2Lw1RECPSi3RyldZ2VcEjdpmb5r6mJZI1ymVzHOS5UUfB2bpSl1qTZ2xgOiKVG_GtJiYDvjvVd5CW6w5DQGi5EITBpYk9bBxHlrh9Ng-8YI0bn_rTPz4IJxc0xVkgY9JstH58ZMmBB8C6C8QuMJ33mNwEHEUxjJadIGDmEBk7_rM3ZfuTkN8TB4U5j2rRAGILkV7P64nXB-JvULzxG-AbtAbZBV791QX5RTHA",
#                           r"C:\Users\Sikha.P\PycharmProjects\findAndReplaceCommandAttributes"
#                          ])