# Author: Sikha Poyyil
#         Global Solution Desk(GSD)
# Company: Automation Anywhere

# Note: Below external libraries to be installed for script to work.
# 1. Requests library to be installed using below cmd
#    Command: pip install requests

import inspect
import json
import logging
import requests
import re

# Global variables defined
logger = logging.getLogger(__name__)
updates_json = None


# Log the messages using logging library
# def initialize_logger(log_file_path, log_level):
#     if not logger.handlers:  # Initialize only if not already initialized
#         logger.setLevel(getattr(logging, log_level.upper()))
#         file_handler = logging.FileHandler(log_file_path, mode='a')
#         formatter = logging.Formatter('%(asctime)s %(levelname)s %(name)s (%(message)s',
#                                       datefmt='(%d-%m-%Y %I.%M.%S %p)')
#
#         file_handler.setFormatter(formatter)
#         logger.addHandler(file_handler)
#
#         log("Log file started.", 'info')
#
#
# def ensure_logger_initialized(log_file_path="app.log", log_level="INFO"):
#     if not logger.handlers:  # If no handlers, initialize logger
#         initialize_logger(log_file_path, log_level)
#
#
# def log(message, level='debug'):
#     ensure_logger_initialized()  # Ensure logger is initialized before logging
#     log_method = getattr(logger, level.lower(), logger.info)
#     log_method(message)


def log(log_msg, log_level):
    # Automatically log the current function details.
    # Get the previous frame in the stack, otherwise it would be this function!!!
    func = inspect.currentframe().f_back.f_code

    # Dump the message + the name of this function to the log.
    logger.log(level=getattr(logging, log_level.upper(), None), msg='{0}): {1}'.format(func.co_name, log_msg))


# Initializing a logger with custom configuration
def initialize_logger(log_file_path, log_level):
    logger.setLevel(getattr(logging, log_level.upper()))
    file_handler = logging.FileHandler(log_file_path, mode='a')
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(name)s (%(message)s', datefmt='(%d-%m-%Y %I.%M.%S %p)')

    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    log("Log file started.", 'info')


# Function to clean data
def clean_text(text):
    if isinstance(text, str):  # Ensure text is a string
        text = text.strip()  # Remove leading/trailing spaces
        text = re.sub(r'[^\w\s]', '', text)  # Remove special characters except spaces
        #text = re.sub(r'\s+', ' ', text)  # Replace multiple spaces with a single space
    return text

def token_status(cr_url, user_token):
    headers = {"accept": "application/json"}

    log("Token status: no data", 'debug')
    log("Headers: " + str(headers), 'debug')
    log("URL: " + cr_url + '/v1/authentication/token?token=' + str(user_token)[0:20], 'debug')

    response = requests.get(cr_url + '/v1/authentication/token?token=' + user_token, headers=headers)

    # Checking if response status is 200
    if response.status_code == 200:
        json_obj = response.json()
        log('Token status: ' + str(json_obj.get('valid')), 'info')
        # print('Token status: ' + str(json_obj.get('valid')))
        return str(json_obj.get('valid'))

    else:
        # Returning error json object
        error_json_obj = response.json()
        log(error_json_obj, 'info')
        # print(str(error_json_obj))
        return error_json_obj


# Generate user token in A360 Control room
def generate_token(cr_url, username, api_key):
    if username != '' and api_key.strip() != '':
        # Api key is not null and password is null
        data = '{ \"username\": \"' + str(username) + '\", \"apiKey\": \"' + str(api_key) + '\"}'
        log("Generate token: data = " + '{ \"username\": \"*********\", \"apiKey\": \"*********\"}', 'debug')

    else:
        # Password and api key both are null
        result = json.dumps({'code': 'user.credentials.empty', 'details': '',
                             'message': 'Both password and api key are null. Please provide either one of them to generate user token'})
        log(result, 'info')
        return result

    headers = {'Content-type': 'application/json', 'Accept': 'application/json'}

    log("Headers: " + str(headers), 'debug')
    log("URL: " + cr_url + '/v2/authentication', 'debug')

    response = requests.post(cr_url + '/v2/authentication', data=data, headers=headers)

    # Checking if response status is 200
    if response.status_code == 200:
        json_obj = response.json()

        # print("User Token: " + str(json_obj.get('token'))[0:20] + ".******")
        log("User Token: " + str(json_obj.get('token'))[0:20] + ".****** generated.", 'info')
        # Returning user token
        return json_obj.get('token')
    else:
        error_json_obj = response.json()

        # print(str(error_json_obj))
        # Returning error json object
        log(str(error_json_obj), 'info')
        return error_json_obj
        
def refresh_token(cr_url, user_token):
    """
    Function to get a new token if the current one expires.
    Modify this to match your actual token refresh API.
    """
    refresh_url = cr_url+"/v2/authentication/token"  # Update this URL
    headers = {"X-Authorization": user_token, 'Content-type': 'application/json', 'Accept': 'text/plain'}
    response = requests.post(refresh_url, headers=headers)

    if response.status_code == 200:
        new_token = response.json().get("token")
        return new_token
    else:
        raise Exception(f"Error: Failed to refresh token: {response.status_code} - {response.text}")


def fetchAuditLogsV2(args):
    try:
        cr_url = args[0]
        username = args[1]
        apikey = args[2]
        starttime = args[3]
        endtime = args[4]
        inputoutputFolderPath = args[5]
        offset = args[6]
        log_file_path = inputoutputFolderPath + "\\fetchAuditLogs.log"

        log_level = 'debug'
        initialize_logger(log_file_path=log_file_path, log_level=log_level)
        log("fetchAuditLogs", log_level)

        token = generate_token(cr_url, username, apikey)
        return fetchAuditlogsByTimerangeV2(cr_url, username, apikey, token, starttime, endtime, log_level,offset)

    except Exception as e:
        log(f"Error in fetchAuditLogs: {str(e)}", 'error')
        return None



def fetchAuditLogsCountV2(args):
    try:
        cr_url = args[0]
        username = args[1]
        apikey = args[2]
        starttime = args[3]
        endtime = args[4]
        inputoutputFolderPath = args[5]
        log_file_path = inputoutputFolderPath + "\\fetchAuditLogs.log"

        log_level = 'debug'
        initialize_logger(log_file_path=log_file_path, log_level=log_level)
        log("fetchAuditLogs", log_level)

        token = generate_token(cr_url, username, apikey)
        return getAuditlogsCountByTimerange(cr_url, username, apikey, token, starttime, endtime, log_level)

    except Exception as e:
        log(f"Error in fetchAuditLogs: {str(e)}", 'error')
        return None

def getAuditlogsCountByTimerange(cr_url, username, apikey, token, starttime, endtime, log_level):
    headers = {
        "X-Authorization": str(token)
    }

    payload = {
        "filter": {
            "operator": "and",
            "operands": [
                {
                    "operator": "gt",
                    "field": "createdOn",
                    "value": starttime
                },
                {
                    "operator": "lt",
                    "field": "createdOn",
                    "value": endtime
                }
            ]
        },
        "sort": [{"field": "createdOn", "direction": "asc"}],
        "page": {
            "offset": 0,  # Using the input offset
            "length": 5      # Fetch only 400 items
        }
    }

    # API Call
    response = requests.post(f"{cr_url}/v1/audit/messages/list", headers=headers, json=payload)
    log(response.status_code, log_level)

    # Handle token expiration (401 error) and refresh token
    if response.status_code == 401:
        log("Token expired, refreshing...", log_level)
        try:
            token = generate_token(cr_url, username, apikey)
            headers["X-Authorization"] = str(token)  # Update headers
            return getAuditlogsCountByTimerange(cr_url, username, apikey, token, starttime, endtime, log_level)
        except Exception as e:
            log(f"Error: Token refresh failed: {str(e)}", log_level)
            return None

    if response.status_code != 200:
        log(f"Error fetching audit logs: {response.status_code} - {response.text}", log_level)
        return None

    data = response.json()
    total_filter = data.get("page", {}).get("totalFilter", 0)  # Extract "totalFilter"

    return total_filter  # Return only "totalFilter" value




def fetchAuditlogsByTimerangeV2(cr_url, username, apikey, token, starttime, endtime, log_level, offset):
    headers = {
        "X-Authorization": str(token)
    }

    payload = {
        "filter": {
            "operator": "and",
            "operands": [
                {
                    "operator": "gt",
                    "field": "createdOn",
                    "value": starttime
                },
                {
                    "operator": "lt",
                    "field": "createdOn",
                    "value": endtime
                }
            ]
        },
        "sort": [{"field": "createdOn", "direction": "asc"}],
        "page": {
            "offset": offset,  # Directly using the input offset
            "length": 400      # Fetch only 400 items
        }
    }

    # API Call
    response = requests.post(f"{cr_url}/v1/audit/messages/list", headers=headers, json=payload)
    log(response.status_code, log_level)

    # Handle token expiration (401 error) and refresh token
    if response.status_code == 401:
        log("Token expired, refreshing...", log_level)
        try:
            token = generate_token(cr_url, username, apikey)
            headers["X-Authorization"] = str(token)  # Update headers
            return fetchAuditlogsByTimerangeV2(cr_url, username, apikey, token, starttime, endtime, log_level, offset)
        except Exception as e:
            log(f"Error: Token refresh failed: {str(e)}", log_level)
            return None

    if response.status_code != 200:
        log(f"Error fetching audit logs: {response.status_code} - {response.text}", log_level)
        return None

    data = response.json()
    items = data.get('list', [])

    return json.dumps({"list": items}, indent=4) if items else None


#fetchAuditLogs(["https://aa-pet-us-17.my.automationanywhere.digital","sikha_creator", "Jgu?]^|`ECIPHnqvb70Maa~RSz|@366WVu@pVa|q","2024-12-01T08:00:00.000Z", "2024-12-10T08:00:00.000Z","C:\\Users\\Sikha.P\\Downloads\\audit"])