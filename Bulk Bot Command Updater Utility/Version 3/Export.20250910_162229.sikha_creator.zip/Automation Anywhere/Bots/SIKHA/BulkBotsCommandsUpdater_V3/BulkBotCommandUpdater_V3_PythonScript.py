# Author: Sikha Poyyil
#         Global Solution Desk(GSD)
# Company: Automation Anywhere

# Note: Below external libraries to be installed for script to work.
# 1. Requests-toolbelt library to be installed using below cmd for BLM apis to work
#    Command: pip install requests-toolbelt

import os
import openpyxl
from openpyxl import Workbook
import json
import traceback
import pandas as pd
import shutil
import inspect
import logging
import csv
import datetime as dt
from pathlib import Path
import requests
from requests_toolbelt.multipart.encoder import MultipartEncoder
from openpyxl.styles import Font
# Global variables defined
logger = logging.getLogger(__name__)
updates_json = None


# Log the messages using logging library
def log(log_msg, log_level):
    # Automatically log the current function details.
    # Get the previous frame in the stack, otherwise it would be this function!!!
    func = inspect.currentframe().f_back.f_code

    # Dump the message + the name of this function to the log.
    logger.log(level=getattr(logging, log_level.upper(), None), msg='{0}): {1}'.format(func.co_name, log_msg))


# Initializing a logger with custom configuration
def initialize_logger(log_file_path, log_level):
    logger.setLevel(getattr(logging, log_level.upper()))
    file_handler = logging.FileHandler(log_file_path, mode='a')
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(name)s (%(message)s', datefmt='(%d-%m-%Y %I.%M.%S %p)')

    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    log("Log file started.", 'info')


# Export bot from A360 Control room
def export_bot(cr_url, username, apikey, export_bot_name, bot_ids):
    data = '{\"name\": \"' + str(export_bot_name) + '\", \"fileIds\": ' \
           + str(bot_ids) + ', \"includePackages\": false}, \"archivePassword\": \"A360@123\"}'
    token = authenticate(cr_url, username, apikey)
    headers = {"X-Authorization": token, 'Content-type': 'application/json', 'Accept': 'text/plain'}

    log("Export bot: " + str(data), 'debug')
    log("Headers: " + str(
        {"X-Authorization": token[0:20] + ".******", 'Content-type': 'application/json', 'Accept': 'text/plain'}),
        'debug')
    log("URL: " + cr_url + '/v2/blm/export', 'debug')

    response = requests.post(cr_url + '/v2/blm/export', data=data, headers=headers)

    # Checking if response status is 202
    if response.status_code == 202:
        json_obj = response.json()
        # print("Exported package request ID: " + str(json_obj.get('requestId')))
        log("Exported package request ID: " + str(json_obj.get('requestId')), 'info')
        return json_obj.get('requestId')

    else:
        error_json_obj = response.json()
        # print(str(error_json_obj))
        log(str(error_json_obj), 'info')
        # Returning error json object
        return error_json_obj


# Get bot package export status
def bot_export_status(cr_url, request_id, username, apikey):
    token = authenticate(cr_url, username, apikey)
    headers = {"X-Authorization": token, "accept": "application/json"}

    log("Export bot status: no data", 'debug')
    log("Headers: " + str({"X-Authorization": token[0:20] + ".******", 'Content-type': 'application/json'}),
        'debug')
    log("URL: " + cr_url + '/v2/blm/status' + request_id, 'debug')

    response = requests.get(cr_url + '/v2/blm/status/' + request_id, headers=headers)

    # Checking if response status is 200
    if response.status_code == 200:
        json_obj = response.json()

        # Checking bot export status
        if json_obj.get('status').lower() == 'completed':
            # print("Download file ID for the exported package: " + str(json_obj.get('downloadFileId')))
            log("Download file ID for the exported package: " + str(json_obj.get('downloadFileId')), 'info')

            # Returning download file id attribute
            return json_obj.get('downloadFileId')

        else:
            # Returning wait
            return 'wait'
    else:
        error_json_obj = response.json()

        # print(str(error_json_obj))
        log(str(error_json_obj), 'info')

        # Returning error json object
        return error_json_obj


# Import bot package into A360 Control room
def bot_import(cr_url, user_token, data_folder_path, data_file_name):
    multipart_data = MultipartEncoder(
        fields={
            # a file upload field
            'upload': (
                data_file_name, open(os.path.join(data_folder_path, data_file_name), 'rb'),
                'application/x-zip-compressed'),
            # plain text fields
            'actionIfExisting': 'OVERWRITE',
            'publicWorkspace': 'true',
            'archivePassword': 'A360@123'
        }
    )

    headers = {"X-Authorization": user_token, "Content-Type": multipart_data.content_type}

    log("Import bot: " + str({
        # a file upload field
        'upload': {'File Path: ' + os.path.join(data_folder_path, data_file_name), 'application/x-zip-compressed'},
        'actionIfExisting': 'OVERWRITE',
        'publicWorkspace': 'true',
        'archivePassword': 'A360@123'
    }), 'debug')
    log("Headers: " + str(
        {"X-Authorization": user_token[0:20] + ".******", "Content-Type": multipart_data.content_type}), 'debug')
    log("URL: " + cr_url + '/v2/blm/import', 'debug')

    response = requests.post(cr_url + '/v2/blm/import', headers=headers, data=multipart_data)

    # Checking if response status is 202
    if response.status_code == 202:
        json_obj = response.json()

        # print("Imported bot package request ID: " + str(json_obj.get('requestId')))
        log("Imported bot package request ID: " + str(json_obj.get('requestId')), 'info')

        return json_obj.get('requestId')
    else:
        error_json_obj = response.json()

        # print(str(error_json_obj))
        log(str(error_json_obj), 'info')

        # Returning error json object
        return error_json_obj


# Download exported bot files into local folder
def download_file(cr_url, download_id, username, apikey, data_file_path):
    token = authenticate(cr_url, username, apikey)
    headers = {"X-Authorization": token, "accept": "*/*", "accept-encoding": "gzip;deflate;br"}

    log("Download file: no data", 'debug')
    log("Headers: " + str(
        {"X-Authorization": token[0:20] + ".******", "accept": "*/*", "accept-encoding": "gzip;deflate;br"}),
        'debug')
    log("URL: " + cr_url + '/v2/blm/download/' + download_id, 'debug')

    response = requests.get(cr_url + '/v2/blm/download/' + download_id, headers=headers)

    # Checking if response status is 200
    if response.status_code == 200:

        with open(data_file_path, 'wb') as output_file:
            output_file.write(response.content)

        # print("File downloaded to: " + str(data_file_path))
        log("File downloaded to: " + str(data_file_path), 'info')

        # Extracting zip file contents
        return "ok"

    else:
        error_json_obj = response.json()

        # print(str(error_json_obj))
        log(str(error_json_obj), 'info')

        # Returning error json object
        return error_json_obj


# Get file details using file path in A360 Control room
def fetch_file_details_by_path(cr_url, user_token, file_path_in_cr):
    data = '{"path": "' + file_path_in_cr + '"}'

    headers = {"X-Authorization": user_token, 'Content-type': 'application/json', 'Accept': 'text/plain'}

    log("Fetch file details by path: " + str(data), 'debug')
    log("Headers: " + str(
        {"X-Authorization": user_token[0:20] + ".******", 'Content-type': 'application/json', 'Accept': 'text/plain'}),
        'debug')
    log("URL: " + cr_url + '/v2/repository/workspaces/public/files/bypath', 'debug')

    response = requests.post(cr_url + '/v2/repository/workspaces/public/files/bypath', data=data, headers=headers)

    # Checking if response status is 200
    if response.status_code == 200:
        json_obj = response.json()

        # print("File ID (" + str(json_obj.get('id')) + ") fetched from control room for file path " + file_path_in_cr)
        log("File ID (" + str(json_obj.get('id')) + ") fetched from control room for file path " + file_path_in_cr,
            'info')

        return json_obj
    else:
        error_json_obj = response.json()

        # print(str(error_json_obj))
        log(str(error_json_obj), 'info')

        # Returning error json object
        return error_json_obj


# Export bot package from A360 Control room
def export_bot_package(args):
    try:
        cr_url = args.get('cr_url')
        apikey = args.get('apikey')
        username = args.get('username')
        # user_token = args.get('user_token')
        bot_ids = args.get('bot_ids')
        data_folder_path = args.get('folder_path')

        export_bot_name = "Export." + dt.datetime.today().strftime('%Y%m%d_%H%M%S') + ".py.utility.zip"

        if str(cr_url).endswith("/"):
            cr_url = cr_url[:-1]

        # Get token status
        # tok_status = token_status(cr_url, user_token)

        # # Checking token status
        # if type(tok_status) == str and tok_status == 'false':
        #     # Returning error
        #     result = json.dumps({'code': 'user.token.invalid', 'details': '',
        #                          'message': 'Given user token is invalid. Please generate a new one.'})
        #     log(str(result), 'info')
        #     return result
        # elif type(tok_status) == dict:
        #     # Returning error
        #     result = json.dumps(tok_status)
        #     log(str(result), 'info')
        #     return result

        # Export bot from control room
        request_id = export_bot(cr_url, username, apikey, export_bot_name, bot_ids)

        # Checking if bot export has started
        if type(request_id) == str and request_id != '':
            download_id = 'wait'

            # Waiting for bot export to be completed
            while type(download_id) == str and download_id == 'wait':
                # Get bot export status
                download_id = bot_export_status(cr_url, request_id, username, apikey)

            # Checking if bot export is completed
            if type(download_id) == str and download_id != 'wait' and download_id != '':
                # Downloading file
                download_obj = download_file(cr_url, download_id, username, apikey,
                                             os.path.join(data_folder_path, export_bot_name))

                # Checking if download is success
                if type(download_obj) == str and download_obj == 'ok':
                    # Returning success
                    log(str(export_bot_name), 'error')
                    return export_bot_name
                else:
                    # Returning error
                    result = json.dumps(download_obj)
                    log(str(result), 'error')
                    return result
            else:
                # Returning error
                result = json.dumps(download_id)
                log(str(result), 'error')
                return result
        else:
            # Returning error
            result = json.dumps(request_id)
            log(str(result), 'error')
            return result
    except Exception as err:
        tb = traceback.extract_tb(err.__traceback__)
        # Get the last entry in the traceback which contains the information about the error
        filename, lineno, _, _ = tb[-1]
        result = json.dumps({
            'code': 'python.exception',
            'details': '',
            'message': str(err),
            'line_number': lineno
        })
        # result = json.dumps({'code': 'python.exception', 'details': '', 'message': str(err)})
        log(str(result), 'error')
        return result


# Export and import bots in A360 Control room
def export_import_bot_package(cr_url, username, apikey, folder_path, bot_ids, inputoutputFolderPath):
    log('Check and create folder path (' + folder_path + ') if not available', 'debug')
    Path(folder_path).mkdir(parents=True, exist_ok=True)
    user_token = authenticate(cr_url, username, apikey)

    if type(user_token) == str:

        log("Bot IDs to be exported: " + str(bot_ids), 'debug')

        # file_name = 'Export.20220816_154744.py.utility.zip'
        file_name = export_bot_package(
            {'cr_url': cr_url, 'username': username, 'apikey': apikey, 'bot_ids': bot_ids, 'folder_path': folder_path})

        # print('file_name: ' + file_name)

        log('Check and create folder path (' + os.environ['temp'] + '\\Backups\\' + file_name.replace('.zip',
                                                                                                      '') + ') if not available',
            'debug')

        print(file_name)
        print(file_name.replace('.zip', ''))
        print(os.environ['temp'] + '\\Backups\\' + file_name.replace('.zip', ''))
        Path(os.environ['temp'] + '\\Backups\\' + file_name.replace('.zip', '')).mkdir(parents=True, exist_ok=True)

        log("Unpacking archive (" + file_name + ").", 'debug')
        shutil.unpack_archive(os.environ['temp'] + '\\Backups\\' + file_name,
                              os.environ['temp'] + '\\Backups\\' + file_name.replace('.zip', ''))

        extracted_folder_path = os.environ['temp'] + '\\Backups\\' + file_name.replace('.zip', '')

        with open(extracted_folder_path + '\\manifest.json', 'r') as f:
            manifest_json = json.load(f)
            f.close()

        # log("Bot files to be edited now: " + str(manifest_json['files']), 'debug')

        local_file_paths = []

        for file in manifest_json['files']:
            if file['contentType'] == 'application/vnd.aa.taskbot':
                local_file_paths.append(extracted_folder_path + '\\' + file['path'])

        log("Bot files to be checked and edited: " + str(local_file_paths), 'debug')

        # print(local_file_paths)

        for local_file_path in local_file_paths:
            is_doc_updated = False
            with open(local_file_path, mode='r', encoding='utf8') as f:
                bot_json = json.load(f)

                variables = []
                if 'variables' in bot_json:
                    for variable in bot_json['variables']:
                        variables.append(variable['name'])

                for node in bot_json['nodes']:
                    res = update_bot_nodes_commands(node, variables, local_file_path, inputoutputFolderPath)
                    if res is True and is_doc_updated is False:
                        is_doc_updated = True
                f.close()

            if is_doc_updated:
                log("Writing bot file back: " + local_file_path, 'debug')
                with open(local_file_path, mode='w', encoding='utf8') as f:
                    f.write(json.dumps(bot_json))

        log("Create archive (" + extracted_folder_path + "_updated.zip).", "debug")
        shutil.make_archive(extracted_folder_path + '_updated', format='zip', root_dir=extracted_folder_path)

        if type(user_token) == str:
            return bot_import(cr_url, user_token, os.environ['temp'] + '\\Backups',
                              file_name.replace('.zip', '_updated.zip'))
        elif type(user_token) == dict:
            result = json.dumps(user_token)
            log(str(result), 'error')
            return result
    elif type(user_token) == dict:
        result = json.dumps(user_token)
        log(str(result), 'error')
        return result


def find_and_update_paths(obj, commandName, packageName, attributeName, currentAttributeValue,newAttributeValue, filepath,
                          inputoutputFolderPath):
    # Check if the top-level object has the required keys
    if isinstance(obj, dict):
        if obj.get("commandName").lower() == commandName and obj.get("packageName").lower() == packageName:
            # Proceed to update paths
            return update_paths(obj, commandName, packageName, attributeName, currentAttributeValue, newAttributeValue,filepath,
                                inputoutputFolderPath)


def extract_botpath(input_string):
    # Split the string at 'utility\' and take the second part
    parts = input_string.split('utility\\')
    if len(parts) > 1:
        return parts[1]
    return None  # Return None if 'utility\' is not found


def update_paths(obj, commandName, packageName, attributeName, currentAttributeValue, newAttributeValue,filepath, inputoutputFolderPath):
    try:
        if isinstance(obj, dict):
            isDisabled = obj.get("disabled")
            if isDisabled:
                return obj
            for key, value in obj.items():
                # Check for "Path" attribute directly in the dictionary
                if key == attributeName and isinstance(value, dict):
                    currentValue = value["value"][(value["value"]["type"]).lower()]
                    if currentValue == newAttributeValue:
                        return obj
                    # Update the Path value
                    value["value"][(value["value"]["type"]).lower()] = newAttributeValue
                    filepath = extract_botpath(filepath)
                    # add_row_to_csv([filepath, commandName, packageName, attributeName, currentAttributeValue, "SUCCESS"])
                    print(inputoutputFolderPath)
                    add_post_update_rows_to_excel(inputoutputFolderPath,
                                                  [filepath, commandName, packageName, attributeName, newAttributeValue,
                                                   "SUCCESS"])
                # Check for "name" attribute
                elif value == attributeName:
                    currentValue = obj["value"][(obj["value"]["type"]).lower()]
                    if currentValue == newAttributeValue:
                        return obj
                    # Update the Path value
                    obj["value"][(obj["value"]["type"]).lower()] = newAttributeValue
                    filepath = extract_botpath(filepath)
                    print(inputoutputFolderPath)
                    add_post_update_rows_to_excel(inputoutputFolderPath,
                                                  [filepath, commandName, packageName, attributeName, newAttributeValue,
                                                   "SUCCESS"])
                    # add_row_to_csv([filepath, commandName, packageName, attributeName, currentAttributeValue, "SUCCESS"])
                # Recursively search in the value
                update_paths(value, commandName, packageName, attributeName, currentAttributeValue,newAttributeValue, filepath,
                             inputoutputFolderPath)
        # If obj is a list, iterate through its elements
        elif isinstance(obj, list):
            for item in obj:
                update_paths(item, commandName, packageName, attributeName, currentAttributeValue,newAttributeValue, filepath,
                             inputoutputFolderPath)

        return obj
    except Exception as e:
        add_post_update_rows_to_excel(inputoutputFolderPath,
                                      [filepath, commandName, packageName, attributeName, newAttributeValue, "FAILED"])
        # add_row_to_csv([filepath, commandName, packageName, attributeName, currentAttributeValue, "FAILED"])
        log(f"An error occurred: {e}", 'debug')


def add_row_to_csv(row_data):
    """
    Adds a new row to the specified CSV file.

    Parameters:
    csv_file_path (str): The path to the CSV file.
    row_data (list): A list containing the row data to be added.
    """
    try:
        csv_file_path = outputCsvReportFilePath
        with open(csv_file_path, mode='a', newline='') as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(row_data)
        print("New row added successfully.")
    except Exception as e:
        print(f"An error occurred: {e}")


# Update bot nodes if changes are required
def update_bot_nodes_commands(node, variables, filepath, inputoutputFolderPath):
    is_doc_updated = False
    global updates_json
    updates = json.loads(updates_json)
    for item in updates:
        # print(item)
        commandName = item.get("Command Name").lower()
        packageName = item.get("Package Name").lower()
        attributeName = item.get("Attribute Name")
        currentAttributeValue = item.get("Current Attribute Value")
        newAttributeValue = item.get("New Attribute Value")# True if item.get("currentAttributeValue") == "true" else False
        # print(attributeName)
        find_and_update_paths(node, commandName, packageName, attributeName, currentAttributeValue,newAttributeValue, filepath,
                              inputoutputFolderPath)
        is_doc_updated = True

    # if node['commandName'].lower() == commandName and node['packageName'].lower() == packageName:
    #  if 'attributes' in node:
    #    for attribute in node['attributes']:
    #    if attribute['name'].lower() == attributeName:
    #      attribute['value']['boolean'] = currentAttributeValue
    #      is_doc_updated = True

    if 'children' in node:
        for sub_node in node['children']:
            res = update_bot_nodes_commands(sub_node, variables, filepath, inputoutputFolderPath)
            if res is True and is_doc_updated is False:
                is_doc_updated = True

    if 'branches' in node:
        for sub_node in node['branches']:
            res = update_bot_nodes_commands(sub_node, variables, filepath, inputoutputFolderPath)
            if res is True and is_doc_updated is False:
                is_doc_updated = True
    return is_doc_updated


# Update bot code if there are any necessary changes
def update_bots(args):
    try:

        cr_url = args[0]
        username = args[1]
        apikey = args[2]
        inputoutputFolderPath = args[3]
        log_file_path = inputoutputFolderPath + "\\bulkbotcommandupdater.log"

        log_level = 'debug'
        initialize_logger(log_file_path=log_file_path, log_level=log_level)
        log("update_bots function called", log_level)

        global updates_json
        global outputCsvReportFilePath
        # outputCsvReportFilePath = inputoutputFolderPath+ '\\postUpdatereport.csv'
        # add_row_to_csv(["Bot Path/ID", "Command Name", "Package Name", "Attribute Name", "Attribute Value", "Status"])

        inputExcelPath = inputoutputFolderPath + "\\input.xlsx"
        df = pd.read_excel(inputExcelPath, sheet_name='Updates')  # Adjust sheet_name as needed
        botUpdatesInput = df.to_json(orient='records')
        updates_json = botUpdatesInput  # data['updates_json']
        # updates_json = data['updates_json']

        # df_botIds = pd.read_excel(inputExcelPath, sheet_name='Bot_IDs')  # Adjust sheet_name as needed
        # Convert the DataFrame to a JSON array
        # df_botIdsJson = df_botIds.to_json(orient='records')
        dfBotIds = pd.read_excel(inputExcelPath, sheet_name="Bot_IDs")
        botids = dfBotIds["Bot Id"].dropna().astype(str).tolist()
        # botids = data['bot_ids'].split(',')
        log(str(botids), 'debug')

        result = export_import_bot_package(cr_url, username, apikey, os.environ['temp'] + '\\Backups', botids,
                                           inputoutputFolderPath)
        # result = export_import_bot_package(data['cr_url'], data['cr_username'], data['cr_password'], data['cr_apikey'],
        #                                    os.environ['temp'] + '\\Backups', botids)
        #
        if os.path.exists(os.environ['temp'] + '\\Backups'):
            shutil.rmtree(os.environ['temp'] + '\\Backups', ignore_errors=True)
        return str(result)
    except Exception as err:
        tb = traceback.extract_tb(err.__traceback__)
        # Get the last entry in the traceback which contains the information about the error
        filename, lineno, _, _ = tb[-1]
        result = json.dumps({
            'code': 'python.exception',
            'details': '',
            'message': str(err),
            'line_number': lineno
        })
        log(str(result), 'info')
        return str(result)


def get_report(args):
    folder_id = args[0]
    cr_url = args[1]
    username = args[2]
    apikey = args[3]
    inputoutputFolderPath = args[4]

    log_file_path = inputoutputFolderPath + "\\bulkbotcommandupdater.log"

    log_level = 'debug'
    initialize_logger(log_file_path=log_file_path, log_level=log_level)
    log("get_report fun called with the: folder_id: " + folder_id,log_level)
    # Create sheet in input xlsx
    return get_files_from_folder(folder_id, cr_url, username, apikey, inputoutputFolderPath)


def find_matching_nodes(node, match_rules):
    matched_nodes = []

    # Skip disabled nodes
    if node.get("disabled") is True:
        return matched_nodes

    for rule in match_rules:
        if (node.get("commandName") == rule["commandName"] and
                node.get("packageName") == rule["packageName"]):

            for attr in node.get("attributes", []):
                if attr.get("name") == rule["attributeName"]:
                    val = attr.get("value", {})
                    rule_val = rule["currentAttributeValue"].strip()

                    # Convert actual value to string
                    actual_val = None
                    if "string" in val:
                        actual_val = str(val["string"]).strip()
                    elif "boolean" in val:
                        actual_val = str(val["boolean"]).strip().lower()
                        rule_val = rule_val.lower()
                    elif "number" in val:
                        actual_val = str(val["number"]).strip()

                    # If it matches (i.e., different from rule)
                    if actual_val is not None and actual_val == rule_val:
                        matched_nodes.append(node)
                        break  # No need to check more rules for this node

    # 🔁 Recursively process children if present
    for group in ["children", "branches"]:
        for child in node.get(group, []):
            matched_nodes.extend(find_matching_nodes(child, match_rules))
    # for child in node.get("children", []):
    #     matched_nodes.extend(find_matching_nodes(child, match_rules))

    return matched_nodes


def matches_node(node, match_rules):
    log(json.dumps(node, indent=2), "debug")

    # Skip disabled nodes
    if node.get("disabled") is True:
        return False

    for rule in match_rules:
        # Match commandName, packageName
        if (node.get("commandName") == rule["commandName"] and
                node.get("packageName") == rule["packageName"]):

            for attr in node.get("attributes", []):
                if attr.get("name") == rule["attributeName"]:
                    val = attr.get("value", {})
                    rule_val = rule["currentAttributeValue"].strip()

                    # Convert actual value to string
                    actual_val = None
                    if "string" in val:
                        actual_val = str(val["string"]).strip()
                    elif "boolean" in val:
                        actual_val = str(val["boolean"]).strip().lower()
                        rule_val = rule_val.lower()
                    elif "number" in val:
                        actual_val = str(val["number"]).strip()

                    # Check if value differs from rule
                    if actual_val is not None and actual_val != rule_val:
                        return True

    # 🔁 Recursively process children if this is a step node
    for child in node.get("children", []):
        if matches_node(child, match_rules):
            return True

    return False  # No match in this node or its children

def load_input_match_rules(filepath):
    wb = openpyxl.load_workbook(filepath)

    # Access the "Updates" sheet instead of the active one
    if "Updates" not in wb.sheetnames:
        raise ValueError(f'Sheet "Updates" not found in {filepath}')

    sheet = wb["Updates"]

    match_rules = []
    for row in sheet.iter_rows(min_row=2, values_only=True):
        match_rules.append({
            "commandName": str(row[0]).strip(),
            "packageName": str(row[1]).strip(),
            "attributeName": str(row[2]).strip(),
            "currentAttributeValue": str(row[3]).strip()
        })
    log(', '.join(str(i) for i in match_rules), "debug")
    return match_rules


def get_file_content(file_id, token, cr_url, username, apikey):
    try:
        headers = {
            "X-Authorization": token
        }
        response = requests.get(f"{cr_url}/v2/repository/files/{file_id}/content", headers=headers)
        if response.status_code == 401:
            token = authenticate(cr_url, username, apikey)
            if not token:
                print("Re-authentication failed.")
                return
            headers["X-Authorization"] = str(token)
            response = requests.post(
                f"{cr_url}/v2/repository/files/{file_id}/content",
                headers=headers
            )
        response.raise_for_status()
        return response.text  # or response.json(), depending on content type
    except requests.RequestException as e:
        print(f"Failed to fetch content for file ID {file_id}: {e}")
        return None


# Auth function to get token
def authenticate(cr_url, username, apikey):
    auth_payload = {
        "username": username,
        "apiKey": apikey
    }
    try:
        response = requests.post(f"{cr_url}/v2/authentication", json=auth_payload)
        response.raise_for_status()
        return response.json().get("token")
    except requests.RequestException as e:
        print(f"Authentication failed: {e}")
        return None


def add_post_update_rows_to_excel(inputoutputFolderPath, row):
    """
    Add rows to an Excel sheet. Create the sheet if it doesn't exist.

    Args:
        filepath (str): Path to the Excel file.
        sheet_name (str): Name of the sheet to write to.
        rows (list of list): List of rows to add (each row is a list of cell values).
    """
    log("add_post_update_rows_to_excel ", "debug")
    filepath = inputoutputFolderPath + "\\input.xlsx"
    header = ["Bot Path/ID", "Command Name", "Package Name", "Attribute Name", "Attribute Value", "Status"]
    try:
        wb = openpyxl.load_workbook(filepath)
    except FileNotFoundError:
        wb = Workbook()

    # Add postupdate row sheet

    if "Post_update_report" in wb.sheetnames:
        sheet2 = wb["Post_update_report"]
    else:
        sheet2 = wb.create_sheet(title="Post_update_report")
        sheet2.append(header)
    sheet2.append(row)
    log("added row to the post_update sheet: " + row[0], "debug")
    wb.save(filepath)


addRowsToExcelCounter = 0


def add_rows_to_excel(filepath, rows, botID):
    """
    Add rows to an Excel sheet. Create the sheet if it doesn't exist.

    Args:
        filepath (str): Path to the Excel file.
        sheet_name (str): Name of the sheet to write to.
        rows (list of list): List of rows to add (each row is a list of cell values).
    """
    global addRowsToExcelCounter
    addRowsToExcelCounter += 1
    log("Going to add rows of " + botID, "debug")
    header = ["Bot Id", "Bot Name", "Bot Path", "Command", "Package"]
    try:
        wb = openpyxl.load_workbook(filepath)
    except FileNotFoundError:
        wb = Workbook()

    # Create sheet if it doesn't exist
    if "Pre_update_report" in wb.sheetnames:
        sheet = wb["Pre_update_report"]
    else:
        sheet = wb.create_sheet(title="Pre_update_report")
        sheet.append(header)

        # Append rows
    for row in rows:
        sheet.append(row)

    # Update BotIDs sheet
    headerBotID = ["Bot Id"]
    if "Bot_IDs" in wb.sheetnames:
        sheet2 = wb["Bot_IDs"]
    else:
        sheet2 = wb.create_sheet(title="Bot_IDs")
        sheet2.append(headerBotID)
    sheet2.append([botID])
    log("Added bot ID: " + botID + " specific rows to the input excel's pre_update_report sheet" , "debug")
    wb.save(filepath)


def add_empty_data_message_to_excel(filepath):
    try:
        wb = openpyxl.load_workbook(filepath)
        sheet = wb.create_sheet(title="Pre_update_report")
        # row = ["No data found for enabled bot commands requiring updates as per the input commands"]
        # sheet.append(row)

        message_lines = [
            "NO MATCHING COMMANDS WERE FOUND. Possible reasons include:",
            "",
            "1. Only ENABLED command lines are being considered.",
            "2. Commands that already have the expected value from the input are excluded."
        ]

        # Styles
        bold_red = Font(bold=True, color="FF0000")  # Red
        bold_black = Font(bold=True, color="000000")  # Black

        # Write each line into the Excel sheet
        for i, line in enumerate(message_lines, start=1):
            cell = sheet.cell(row=i, column=1, value=line)
            cell.font = bold_red if i == 1 else bold_black
        wb.save(filepath)
        log("Added new row to the input excel's pre_update_report sheet: " , "debug")
    except FileNotFoundError:
        wb = Workbook()


# Main function to get files
def get_files_from_folder(folder_id, cr_url, username, apikey, inputoutputFolderPath):
    global addRowsToExcelCounter
    token = authenticate(cr_url, username, apikey)
    if not token:
        print("Failed to authenticate. Exiting.")
        return None

    all_files = []
    botIDs = []
    seen_items = set()  # Track IDs to prevent duplicates
    processed_subfolders = set()  # Track processed subfolders
    matched_files = []
    match_rules = load_input_match_rules(inputoutputFolderPath + "\\input.xlsx")

    def fetch_folder(folder_id, token):
        log("inside fetch folder" + folder_id, "debug")
        nonlocal all_files
        page_number = 0

        while True:
            headers = {
                "X-Authorization": str(token)
            }

            payload = {
                "filter": {},
                "sort": [{"field": "id", "direction": "desc"}],
                "page": {
                    "offset": page_number * 100,
                    "length": 100
                }
            }

            response = requests.post(
                f"{cr_url}/v2/repository/folders/{folder_id}/list",
                headers=headers,
                json=payload
            )

            if response.status_code == 401:
                print("Token expired or unauthorized. Re-authenticating...")
                token = authenticate(cr_url, username, apikey)
                if not token:
                    print("Re-authentication failed.")
                    return
                headers["X-Authorization"] = str(token)
                response = requests.post(
                    f"{cr_url}/v2/repository/folders/{folder_id}/list",
                    headers=headers,
                    json=payload
                )

            data = response.json()
            items = data.get("list", [])

            # Stop pagination if no new items are received
            new_items = [item for item in items if item['id'] not in seen_items]
            if not new_items:
                break

            for item in new_items:
                seen_items.add(item['id'])  # Track item ID to avoid duplication

                if item['type'] == 'application/vnd.aa.taskbot':
                    matched_files = []
                    log("Found a taskbot" + item['id'], "debug")
                    all_files.append(item)  # Store full item details
                    content = get_file_content(item['id'], token, cr_url, username, apikey)
                    if not content:
                        continue

                    try:
                        content_json = json.loads(content)
                        log("Analysing taskbot content", "debug")
                        nodes = content_json.get("nodes", [])
                        for node in nodes:
                            all_matches = find_matching_nodes(node, match_rules)
                            for match in all_matches:
                                log("Match nodes found", "debug")
                                matched_files.append([item['id'], item['name'], item['path'], match.get("commandName"),
                                                      match.get("packageName")])
                            # if matches_node(node, match_rules):
                            #     matched_files.append([item['id'], item['name'], item['path'], node.get("commandName"),
                            #                           node.get("packageName")])

                        # insert each bot specific rows into excel in one go
                        if len(matched_files) > 0:
                            log("matched_files length more than 0. so adding it to the input excel pre_update_report sheet", "debug")
                            add_rows_to_excel(
                                inputoutputFolderPath + "\\input.xlsx",
                                matched_files,
                                item['id']
                            )




                    except Exception as e:
                        print(f"JSON parse error for {item.get('name')}: {e}")

                elif item['type'] == 'application/vnd.aa.directory' and item['id'] not in processed_subfolders:
                    processed_subfolders.add(item['id'])  # Mark subfolder as processed
                    fetch_folder(item['id'], token)  # Recursively fetch subfolder contents

            page_number += 1  # Move to the next page for pagination

    fetch_folder(folder_id, token)
    formatted_json = json.dumps({"list": all_files}, indent=4)
    if addRowsToExcelCounter == 0:
        add_empty_data_message_to_excel(inputoutputFolderPath+"\\input.xlsx")
    # print(formatted_json)
    return formatted_json


# load_input_match_rules("C:\\Users\\Sikha.P\\OneDrive - Automation Anywhere Software Private Limited\\AA_SIKHA\\AA_SIKHA\\EA Tickets\\BulkCommandUpdater\\input.xlsx")

# update_bots({ "cr_url": "https://aa-pet-us-17.my.automationanywhere.digital",    "cr_username": "sikha_creator2",    "cr_password": "password",  "input_output_folder_path": "C:\\Users\\Sikha.P\\PycharmProjects\\findAndReplaceCommandAttributes",   "log_level": "debug",    "bot_ids": "21158,21114",    "inputExcelPath": "C:\\Users\\Sikha.P\\PycharmProjects\\findAndReplaceCommandAttributes\\input.xlsx"})

# update_bots(["https://aa-pet-us-17.my.automationanywhere.digital", "sikha_creator",
#              "f_Naxj8I?<I_SkRC@OAEqeDI:W8=LL`gf;iBWel_",
#              "C:\\Users\\Sikha.P\\Downloads\\out"])

# getAllTaskBotsByFolderID(["20971","https://aa-pet-us-17.my.automationanywhere.digital","eyJhbGciOiJSUzUxMiJ9.eyJzdWIiOiIyMzciLCJjbGllbnRUeXBlIjoiV0VCIiwidGVuYW50VXVpZCI6IjBhNjY1YzQ2LTc4ZWUtMTI2NC04MTc5LWE1MzI5NjMwMDJhYyIsIm11bHRpcGxlTG9naW4iOmZhbHNlLCJpYXQiOjE3Mjk3MDgzNDQsImV4cCI6MTcyOTcwOTU0NCwiaXNzIjoiQXV0b21hdGlvbkFueXdoZXJlIiwibmFub1RpbWUiOjY2MjYwNjc5NDU3NjYxNX0.f9n4Wc1KENdy3rULuBSb2kp5Ef4-9EF9l2gmyO3QJLB9L01AevdKJHkOA7Eah_wuQfwBUNC5_KQPcwOrRQq2BwEzV7EG7LzrWbUYMyhCavGtFxuq14MLRLUIaM76M3c5LIuH_lFlLrHLMR3V5Bw9mU3nPsxpVDZxHfKAMJVRHObqURrfp--2ZkVTqAkmGqsdHLowDII7tvHpXZx94U-4Tdv6FVW14cqnnVjNpjAs2TUZt6jkqpZKMC7-EICuavKWuLuEya9iNvwQQ_JvC5n0sxty2U5xobZ4tS1TjbvQ57zBrBH5koHC0To1K2nH1R2E_vwk8pP9Dp_50i4XO7QHiQ","0"])
# get_report(["1108", "https://aa-pet-us-17.my.automationanywhere.digital", "sikha_creator",
#             "f_Naxj8I?<I_SkRC@OAEqeDI:W8=LL`gf;iBWel_",
#             "C:\\Users\\Sikha.P\\Downloads\\out"])
