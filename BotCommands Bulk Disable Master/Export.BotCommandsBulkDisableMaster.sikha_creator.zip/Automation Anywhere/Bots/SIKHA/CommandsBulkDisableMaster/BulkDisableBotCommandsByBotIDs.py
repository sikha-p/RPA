# Author: Sikha Poyyil
#         Global Solution Desk(GSD)
# Company: Automation Anywhere

# Note: Below external libraries to be installed for script to work.
# 1. Requests-toolbelt library to be installed using below cmd for BLM apis to work
#    Command: pip install requests-toolbelt

import os
import copy
import json
import traceback
import pandas as pd
import uuid
import shutil
import inspect
import logging
import requests
import csv
import datetime as dt
from pathlib import Path
import requests
from requests_toolbelt.multipart.encoder import MultipartEncoder

# Global variables defined
logger = logging.getLogger(__name__)
updates_json = None


# Log the messages using logging library
def log(log_msg, log_level):
    # Automatically log the current function details.
    # Get the previous frame in the stack, otherwise it would be this function!!!
    func = inspect.currentframe().f_back.f_code

    # Dump the message + the name of this function to the log.
    logger.log(level=getattr(logging, log_level.upper(), None), msg='{0}): {1}'.format(func.co_name, log_msg))


# Initializing a logger with custom configuration
def initialize_logger(log_file_path, log_level):
    logger.setLevel(getattr(logging, log_level.upper()))
    file_handler = logging.FileHandler(log_file_path, mode='a')
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(name)s (%(message)s', datefmt='(%d-%m-%Y %I.%M.%S %p)')

    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    log("Log file started.", 'info')


def refresh_token(cr_url, user_token):
    """
    Function to get a new token if the current one expires.
    Modify this to match your actual token refresh API.
    """
    refresh_url = cr_url+"/v2/authentication/token"  # Update this URL
    headers = {"X-Authorization": user_token, 'Content-type': 'application/json', 'Accept': 'text/plain'}
    response = requests.post(refresh_url, headers=headers)

    if response.status_code == 200:
        new_token = response.json().get("token")
        return new_token
    else:
        raise Exception(f"Error: Failed to refresh token: {response.status_code} - {response.text}")

# Get user token status - valid or invalid
def token_status(cr_url, user_token):
    headers = {"accept": "application/json"}

    log("Token status: no data", 'debug')
    log("Headers: " + str(headers), 'debug')
    log("URL: " + cr_url + '/v1/authentication/token?token=' + str(user_token)[0:20], 'debug')

    response = requests.get(cr_url + '/v1/authentication/token?token=' + user_token, headers=headers)

    # Checking if response status is 200
    if response.status_code == 200:
        json_obj = response.json()
        log('Token status: ' + str(json_obj.get('valid')), 'info')
        # print('Token status: ' + str(json_obj.get('valid')))
        return str(json_obj.get('valid'))

    else:
        # Returning error json object
        error_json_obj = response.json()
        log(error_json_obj, 'info')
        # print(str(error_json_obj))
        return error_json_obj


# Generate user token in A360 Control room
def generate_token(cr_url, username, api_key):
    if api_key.strip() != '':
        # Api key is not null
        data = '{ \"username\": \"' + str(username) + '\", \"apiKey\": \"' + str(api_key) + '\"}'
        log("Generate token: data = " + '{ \"username\": \"*********\", \"apiKey\": \"*********\"}', 'debug')

    else:
        #  api key is null
        result = json.dumps({'code': 'user.credentials.empty', 'details': '',
                             'message': 'APIKey value is null. Please provide either one of them to generate user token'})
        log(result, 'info')
        return result

    headers = {'Content-type': 'application/json', 'Accept': 'application/json'}

    log("Headers: " + str(headers), 'debug')
    log("URL: " + cr_url + '/v2/authentication', 'debug')
    response = requests.post(cr_url + '/v2/authentication', data=data, headers=headers)

    # Checking if response status is 200
    if response.status_code == 200:
        json_obj = response.json()
        log("User Token: " + str(json_obj.get('token'))[0:20] + ".****** generated.", 'info')
        # Returning user token
        return json_obj.get('token')
    else:
        error_json_obj = response.json()
        # Returning error json object
        log(str(error_json_obj), 'info')
        return error_json_obj


# Export bot from A360 Control room
def export_bot(cr_url, user_token, export_bot_name, bot_ids):
    data = '{\"name\": \"' + str(export_bot_name) + '\", \"fileIds\": ' \
           + str(bot_ids) + ', \"includePackages\": false}, \"archivePassword\": \"A360@123\"}'

    headers = {"X-Authorization": user_token, 'Content-type': 'application/json', 'Accept': 'text/plain'}

    log("Export bot: " + str(data), 'debug')
    log("Headers: " + str(
        {"X-Authorization": user_token[0:20] + ".******", 'Content-type': 'application/json', 'Accept': 'text/plain'}),
        'debug')
    log("URL: " + cr_url + '/v2/blm/export', 'debug')

    response = requests.post(cr_url + '/v2/blm/export', data=data, headers=headers)

    # Checking if response status is 202
    if response.status_code == 202:
        json_obj = response.json()
        # print("Exported package request ID: " + str(json_obj.get('requestId')))
        log("Exported package request ID: " + str(json_obj.get('requestId')), 'info')
        return json_obj.get('requestId')

    else:
        error_json_obj = response.json()
        # print(str(error_json_obj))
        log(str(error_json_obj), 'info')
        # Returning error json object
        return error_json_obj


# Get bot package export status
def bot_export_status(cr_url, request_id, user_token):
    headers = {"X-Authorization": user_token, "accept": "application/json"}

    log("Export bot status: no data", 'debug')
    log("Headers: " + str({"X-Authorization": user_token[0:20] + ".******", 'Content-type': 'application/json'}),
        'debug')
    log("URL: " + cr_url + '/v2/blm/status' + request_id, 'debug')

    response = requests.get(cr_url + '/v2/blm/status/' + request_id, headers=headers)

    # Checking if response status is 200
    if response.status_code == 200:
        json_obj = response.json()

        # Checking bot export status
        if json_obj.get('status').lower() == 'completed':
            # print("Download file ID for the exported package: " + str(json_obj.get('downloadFileId')))
            log("Download file ID for the exported package: " + str(json_obj.get('downloadFileId')), 'info')

            # Returning download file id attribute
            return json_obj.get('downloadFileId')

        else:
            # Returning wait
            return 'wait'
    else:
        error_json_obj = response.json()

        # print(str(error_json_obj))
        log(str(error_json_obj), 'info')

        # Returning error json object
        return error_json_obj


# Import bot package into A360 Control room
def bot_import(cr_url, user_token, data_folder_path, data_file_name):
    multipart_data = MultipartEncoder(
        fields={
            # a file upload field
            'upload': (
                data_file_name, open(os.path.join(data_folder_path, data_file_name), 'rb'),
                'application/x-zip-compressed'),
            # plain text fields
            'actionIfExisting': 'OVERWRITE',
            'publicWorkspace': 'true',
            'archivePassword': 'A360@123'
        }
    )

    headers = {"X-Authorization": user_token, "Content-Type": multipart_data.content_type}

    log("Import bot: " + str({
        # a file upload field
        'upload': {'File Path: ' + os.path.join(data_folder_path, data_file_name), 'application/x-zip-compressed'},
        'actionIfExisting': 'OVERWRITE',
        'publicWorkspace': 'true',
        'archivePassword': 'A360@123'
    }), 'debug')
    log("Headers: " + str(
        {"X-Authorization": user_token[0:20] + ".******", "Content-Type": multipart_data.content_type}), 'debug')
    log("URL: " + cr_url + '/v2/blm/import', 'debug')

    response = requests.post(cr_url + '/v2/blm/import', headers=headers, data=multipart_data)

    # Checking if response status is 202
    if response.status_code == 202:
        json_obj = response.json()

        # print("Imported bot package request ID: " + str(json_obj.get('requestId')))
        log("Imported bot package request ID: " + str(json_obj.get('requestId')), 'info')

        return json_obj.get('requestId')
    else:
        error_json_obj = response.json()

        # print(str(error_json_obj))
        log(str(error_json_obj), 'info')

        # Returning error json object
        return error_json_obj


# Download exported bot files into local folder
def download_file(cr_url, download_id, user_token, data_file_path):
    headers = {"X-Authorization": user_token, "accept": "*/*", "accept-encoding": "gzip;deflate;br"}

    log("Download file: no data", 'debug')
    log("Headers: " + str(
        {"X-Authorization": user_token[0:20] + ".******", "accept": "*/*", "accept-encoding": "gzip;deflate;br"}),
        'debug')
    log("URL: " + cr_url + '/v2/blm/download/' + download_id, 'debug')

    response = requests.get(cr_url + '/v2/blm/download/' + download_id, headers=headers)

    # Checking if response status is 200
    if response.status_code == 200:

        with open(data_file_path, 'wb') as output_file:
            output_file.write(response.content)

        # print("File downloaded to: " + str(data_file_path))
        log("File downloaded to: " + str(data_file_path), 'info')

        # Extracting zip file contents
        return "ok"

    else:
        error_json_obj = response.json()

        # print(str(error_json_obj))
        log(str(error_json_obj), 'info')

        # Returning error json object
        return error_json_obj



# Export bot package from A360 Control room
def export_bot_package(args):
    try:
        cr_url = args.get('cr_url')
        user_token = args.get('user_token')
        bot_ids = args.get('bot_ids')
        data_folder_path = args.get('folder_path')

        export_bot_name = "Export." + dt.datetime.today().strftime('%Y%m%d_%H%M%S') + ".py.utility.zip"

        if str(cr_url).endswith("/"):
            cr_url = cr_url[:-1]

        # Get token status
        tok_status = token_status(cr_url, user_token)

        # Checking token status
        if type(tok_status) == str and tok_status == 'false':
            # Returning error
            result = json.dumps({'code': 'user.token.invalid', 'details': '',
                                 'message': 'Given user token is invalid. Please generate a new one.'})
            log(str(result), 'info')
            return result
        elif type(tok_status) == dict:
            # Returning error
            result = json.dumps(tok_status)
            log(str(result), 'info')
            return result

        # Export bot from control room
        request_id = export_bot(cr_url, user_token, export_bot_name, bot_ids)

        # Checking if bot export has started
        if type(request_id) == str and request_id != '':
            download_id = 'wait'

            # Waiting for bot export to be completed
            while type(download_id) == str and download_id == 'wait':
                # Get bot export status
                download_id = bot_export_status(cr_url, request_id, user_token)

            # Checking if bot export is completed
            if type(download_id) == str and download_id != 'wait' and download_id != '':
                # Downloading file
                download_obj = download_file(cr_url, download_id, user_token,
                                             os.path.join(data_folder_path, export_bot_name))

                # Checking if download is success
                if type(download_obj) == str and download_obj == 'ok':
                    # Returning success
                    log(str(export_bot_name), 'error')
                    return export_bot_name
                else:
                    # Returning error
                    result = json.dumps(download_obj)
                    log(str(result), 'error')
                    return result
            else:
                # Returning error
                result = json.dumps(download_id)
                log(str(result), 'error')
                return result
        else:
            # Returning error
            log("request id " + request_id, 'debug')
            result = json.dumps(request_id)

            log(str(result), 'error')
            return result
    except Exception as err:
        tb = traceback.extract_tb(err.__traceback__)
        # Get the last entry in the traceback which contains the information about the error
        filename, lineno, _, _ = tb[-1]
        result = json.dumps({
            'code': 'python.exception',
            'details': '',
            'message': str(err),
            'line_number': lineno
        })
        #result = json.dumps({'code': 'python.exception', 'details': '', 'message': str(err)})
        log(str(result), 'error')
        return result


# Export and import bots in A360 Control room
def export_import_bot_package(cr_url, username, api_key, folder_path,bot_ids):
    log('Check and create folder path (' + folder_path + ') if not available', 'debug')
    Path(folder_path).mkdir(parents=True, exist_ok=True)
    user_token = generate_token(cr_url, username, api_key)

    if type(user_token) == str:

        log("Bot IDs to be exported: " + str(bot_ids), 'debug')

        # file_name = 'Export.20220816_154744.py.utility.zip'
        file_name = export_bot_package(
            {'cr_url': cr_url, 'user_token': user_token, 'bot_ids': bot_ids, 'folder_path': folder_path})

        # print('file_name: ' + file_name)

        log('Check and create folder path (' + os.environ['temp'] + '\\Backups\\' + file_name.replace('.zip',
                                                                                                      '') + ') if not available',
            'debug')

        print(file_name)
        print(file_name.replace('.zip', ''))
        print(os.environ['temp'] + '\\Backups\\' + file_name.replace('.zip', ''))
        Path(os.environ['temp'] + '\\Backups\\' + file_name.replace('.zip', '')).mkdir(parents=True, exist_ok=True)

        log("Unpacking archive (" + file_name + ").", 'debug')
        shutil.unpack_archive(os.environ['temp'] + '\\Backups\\' + file_name,
                              os.environ['temp'] + '\\Backups\\' + file_name.replace('.zip', ''))

        extracted_folder_path = os.environ['temp'] + '\\Backups\\' + file_name.replace('.zip', '')

        with open(extracted_folder_path + '\\manifest.json', 'r') as f:
            manifest_json = json.load(f)
            f.close()

        # log("Bot files to be edited now: " + str(manifest_json['files']), 'debug')

        local_file_paths = []

        for file in manifest_json['files']:
            if file['contentType'] == 'application/vnd.aa.taskbot':
                local_file_paths.append(extracted_folder_path + '\\' + file['path'])

        log("Bot files to be checked and edited: " + str(local_file_paths), 'debug')

        # print(local_file_paths)

        for local_file_path in local_file_paths:
            is_doc_updated = False
            with open(local_file_path, mode='r', encoding='utf8') as f:
                bot_json = json.load(f)

                variables = []
                if 'variables' in bot_json:
                    for variable in bot_json['variables']:
                        variables.append(variable['name'])

                for node in bot_json['nodes']:
                    res = update_bot_nodes_commands(node, variables,local_file_path)
                    if res is True and is_doc_updated is False:
                        is_doc_updated = True
                f.close()

            if is_doc_updated:
                log("Writing bot file back: " + local_file_path, 'debug')
                with open(local_file_path, mode='w', encoding='utf8') as f:
                    f.write(json.dumps(bot_json))

        log("Create archive (" + extracted_folder_path + "_updated.zip).", "debug")
        shutil.make_archive(extracted_folder_path + '_updated', format='zip', root_dir=extracted_folder_path)

        if type(user_token) == str:
            return bot_import(cr_url, user_token, os.environ['temp'] + '\\Backups',
                              file_name.replace('.zip', '_updated.zip'))
        elif type(user_token) == dict:
            result = json.dumps(user_token)
            log(str(result), 'error')
            return result
    elif type(user_token) == dict:
        result = json.dumps(user_token)
        log(str(result), 'error')
        return result



def find_and_update_commands(obj,commandName,packageName,attributeName,attributeValue,filepath):
    # Check if the top-level object has the required keys
    if isinstance(obj, dict):
        if obj.get("commandName").lower() == commandName and obj.get("packageName").lower() ==packageName:
            # Proceed to update paths
            return disable_command(obj,commandName,packageName,attributeName,attributeValue,filepath)

def extract_botpath(input_string):
    # Split the string at 'utility\' and take the second part
    parts = input_string.split('utility\\')
    if len(parts) > 1:
        return parts[1]
    return None  # Return None if 'utility\' is not found

def disable_command(obj,commandName,packageName,attributeName,attributeValue,filepath):
    try:
        if isinstance(obj, dict):
            for key, value in obj.items():
                if key == attributeName:
                    print("from 462" + key)
                    obj[key] = attributeValue
                    print(str(obj))
                    filepath = extract_botpath(filepath)
                    add_row_to_csv([filepath, commandName, packageName, attributeName, attributeValue, "SUCCESS"])
        # If obj is a list, iterate through its elements
        elif isinstance(obj, list):
            for item in obj:
                disable_command(item, commandName, packageName, attributeName, attributeValue, filepath)

        return obj
    except Exception as e:
        add_row_to_csv([filepath, commandName, packageName, attributeName, attributeValue, "FAILED"])
        log(f"An error occurred: {e}",'debug')


def add_row_to_csv(row_data):
    """
    Adds a new row to the specified CSV file.

    Parameters:
    csv_file_path (str): The path to the CSV file.
    row_data (list): A list containing the row data to be added.
    """
    try:
        csv_file_path = outputCsvReportFilePath
        with open(csv_file_path, mode='a', newline='') as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(row_data)
        print("New row added successfully.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Update bot nodes if changes are required
def update_bot_nodes_commands(node, variables,filepath):
    is_doc_updated = False
    global updates_json
    updates = json.loads(updates_json)
    for item in updates:
        print(item)
        commandName = item.get("Command Name").lower()
        packageName = item.get("Package Name").lower()
        attributeName = "disabled"
        attributeValue = True
        print(attributeName)
        find_and_update_commands(node,commandName,packageName, attributeName, attributeValue,filepath)
        is_doc_updated = True


    if 'children' in node:
        for sub_node in node['children']:
            res = update_bot_nodes_commands(sub_node, variables,filepath)
            if res is True and is_doc_updated is False:
                is_doc_updated = True

    if 'branches' in node:
        for sub_node in node['branches']:
            res = update_bot_nodes_commands(sub_node, variables,filepath)
            if res is True and is_doc_updated is False:
                is_doc_updated = True
    return is_doc_updated


# Update bot code if there are any necessary changes
def update_bot_code(data):
    try:


        data = json.loads(data)


        log_file_path = data['input_output_folder_path']  + "\\botCommandsBulkDisable.log"

        log_level = data['log_level']
        initialize_logger(log_file_path=log_file_path, log_level=log_level)
        log(str('helllo'), 'debug')
        log(str(data['input_output_folder_path'] ), 'debug')
        if 'cr_url' not in data:
            return json.dumps({'code': 'python.exception', 'details': '',
                               'message': 'Control room URL is missing, please provide and run the utility again.'})
        elif 'cr_username' not in data:
            return json.dumps({'code': 'python.exception', 'details': '',
                               'message': 'Username is missing, please provide it for authentication.'})
        elif 'cr_apikey' not in data:
            return json.dumps({'code': 'python.exception', 'details': '',
                               'message': 'APIKey is missing, please provide either of them for authentication.'})



        global updates_json
        global outputCsvReportFilePath
        outputCsvReportFilePath = data['input_output_folder_path']  + '\\postUpdatereport.csv'
        add_row_to_csv(["Bot Path/ID", "Command Name", "Package Name", "Attribute Name", "Attribute Value", "Status"])

        inputExcelPath = data['inputExcelPath']
        df = pd.read_excel(inputExcelPath, sheet_name='Updates')  # Adjust sheet_name as needed
        botUpdatesInput = df.to_json(orient='records')
        updates_json = botUpdatesInput  # data['updates_json']

        botids = data['bot_ids'].split(',')
        log(str(botids), 'debug')

        if 'cr_apikey' not in data:
            data['cr_apikey'] = ''


        result = export_import_bot_package(data['cr_url'], data['cr_username'], data['cr_apikey'], os.environ['temp'] + '\\Backups',botids)

        if os.path.exists(os.environ['temp'] + '\\Backups'):
            shutil.rmtree(os.environ['temp'] + '\\Backups', ignore_errors=True)
        return str(result)
    except Exception as err:
        tb = traceback.extract_tb(err.__traceback__)
        # Get the last entry in the traceback which contains the information about the error
        filename, lineno, _, _ = tb[-1]
        result = json.dumps({
            'code': 'python.exception',
            'details': '',
            'message': str(err),
            'line_number': lineno
        })
        log(str(result), 'info')
        return str(result)

def getAllTaskBotsByFolderID(args):
    folder_id = args[0]
    cr_url = args[1]
    token = args[2]
    inputoutputFolderPath = args[3]
    log_file_path = inputoutputFolderPath + "\\botCommandsBulkDisable.log"

    log_level = 'debug'
    initialize_logger(log_file_path=log_file_path, log_level=log_level)
    log("getAllTaskBotsByFolderID", log_level)

    taskbots = []
    return get_files_from_folder(folder_id,cr_url,token,log_level)


def get_files_from_folder(folder_id, cr_url, token, log_level):
    headers = {"X-Authorization": str(token)}

    all_files = []  # Store full TaskBot details
    seen_items = set()  # Track IDs to prevent duplicates
    processed_subfolders = set()  # Track processed subfolders
    token_refreshed = False  # Track if token was refreshed

    def fetch_files(folder_id):
        nonlocal token, headers, token_refreshed
        page_number = 0

        try:
            while True:
                payload = {
                    "filter": {},
                    "sort": [{"field": "id", "direction": "desc"}],
                    "page": {
                        "offset": page_number * 100,
                        "length": 100
                    }
                }

                response = requests.post(f"{cr_url}/v2/repository/folders/{folder_id}/list", headers=headers,
                                         json=payload)

                # Handle unauthorized (401) error and refresh token
                if response.status_code == 401 and not token_refreshed:
                    log("Token expired, refreshing...", log_level)
                    try:
                        token = refresh_token(cr_url, token)  # Get a new token
                        headers["X-Authorization"] = str(token)  # Update headers
                        token_refreshed = True  # Prevent multiple refresh attempts
                        return fetch_files(folder_id)  # Retry the request
                    except Exception as e:
                        log(f"Error: Token refresh failed: {str(e)}", log_level)
                        return

                # Handle other errors
                if response.status_code != 200:
                    log(f"Error: fetching folder contents: {response.status_code} - {response.text}", log_level)
                    return

                data = response.json()
                items = data.get('list', [])

                # Stop pagination if no new items are received
                new_items = [item for item in items if item['id'] not in seen_items]
                if not new_items:
                    break

                for item in new_items:
                    seen_items.add(item['id'])  # Track item ID to avoid duplication

                    if item['type'] == 'application/vnd.aa.taskbot':
                        all_files.append(item)  # Store full item details
                    elif item['type'] == 'application/vnd.aa.directory' and item['id'] not in processed_subfolders:
                        processed_subfolders.add(item['id'])  # Mark subfolder as processed
                        fetch_files(item['id'])  # Recursively fetch subfolder contents

                page_number += 1  # Move to the next page for pagination

        except requests.exceptions.RequestException as e:
            log(f"Error: Request failed: {str(e)}", log_level)
        except Exception as e:
            log(f"Unexpected Error: {str(e)}", log_level)

    try:
        fetch_files(folder_id)
        formatted_json = json.dumps({"list": all_files}, indent=4)
        return formatted_json
    except Exception as e:
        log(f"Critical error in fetching files: {str(e)}", log_level)
        return json.dumps({"Error": "Failed to retrieve files"})



#update_bot_code({ "cr_url": "https://aa-pet-us-17.my.automationanywhere.digital",    "cr_username": "sikha_creator2",    "cr_password": "password",  "input_output_folder_path": "C:\\Users\\Sikha.P\\PycharmProjects\\findAndReplaceCommandAttributes",   "log_level": "debug",    "bot_ids": "21158,21114",    "inputExcelPath": "C:\\Users\\Sikha.P\\PycharmProjects\\findAndReplaceCommandAttributes\\input.xlsx"})

#update_bot_code({ "cr_url": "https://aa-pet-us-17.my.automationanywhere.digital",    "cr_username": "sikha_creator",    "cr_apikey": "36C=Hls22iQMDvJY1eBSb9V0FQmSP~Gk:AO:K?Wh",  "input_output_folder_path": "C:\\Users\\Sikha.P\\PycharmProjects\\inputFolder",   "log_level": "debug",    "bot_ids": "18747,18748",    "inputExcelPath": "C:\\Users\\Sikha.P\\PycharmProjects\\inputFolder\\input.xlsx"})

#getAllTaskBotsByFolderID(["20971","https://aa-pet-us-17.my.automationanywhere.digital","eyJhbGciOiJSUzUxMiJ9.eyJzdWIiOiIyMzciLCJjbGllbnRUeXBlIjoiV0VCIiwidGVuYW50VXVpZCI6IjBhNjY1YzQ2LTc4ZWUtMTI2NC04MTc5LWE1MzI5NjMwMDJhYyIsIm11bHRpcGxlTG9naW4iOmZhbHNlLCJpYXQiOjE3Mjk3MDgzNDQsImV4cCI6MTcyOTcwOTU0NCwiaXNzIjoiQXV0b21hdGlvbkFueXdoZXJlIiwibmFub1RpbWUiOjY2MjYwNjc5NDU3NjYxNX0.f9n4Wc1KENdy3rULuBSb2kp5Ef4-9EF9l2gmyO3QJLB9L01AevdKJHkOA7Eah_wuQfwBUNC5_KQPcwOrRQq2BwEzV7EG7LzrWbUYMyhCavGtFxuq14MLRLUIaM76M3c5LIuH_lFlLrHLMR3V5Bw9mU3nPsxpVDZxHfKAMJVRHObqURrfp--2ZkVTqAkmGqsdHLowDII7tvHpXZx94U-4Tdv6FVW14cqnnVjNpjAs2TUZt6jkqpZKMC7-EICuavKWuLuEya9iNvwQQ_JvC5n0sxty2U5xobZ4tS1TjbvQ57zBrBH5koHC0To1K2nH1R2E_vwk8pP9Dp_50i4XO7QHiQ","0"])