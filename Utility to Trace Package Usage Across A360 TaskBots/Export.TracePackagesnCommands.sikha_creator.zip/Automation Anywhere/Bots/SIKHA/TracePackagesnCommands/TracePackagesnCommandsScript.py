# Author: Sikha Poyyil
#         Global Solution Desk(GSD)
# Company: Automation Anywhere

# Note: Below external libraries to be installed for script to work.
# 1. Requests-toolbelt library to be installed using below cmd for BLM apis to work
#    Command: pip install requests-toolbelt

import os
import openpyxl
from openpyxl import Workbook
import json
import traceback
import pandas as pd
import shutil
import inspect
import logging
import csv
import datetime as dt
from pathlib import Path
import requests
from requests_toolbelt.multipart.encoder import MultipartEncoder
from openpyxl.styles import Font
# Global variables defined
logger = logging.getLogger(__name__)
updates_json = None


# Log the messages using logging library
def log(log_msg, log_level):
    # Automatically log the current function details.
    # Get the previous frame in the stack, otherwise it would be this function!!!
    func = inspect.currentframe().f_back.f_code

    # Dump the message + the name of this function to the log.
    logger.log(level=getattr(logging, log_level.upper(), None), msg='{0}): {1}'.format(func.co_name, log_msg))


# Initializing a logger with custom configuration
def initialize_logger(log_file_path, log_level):
    logger.setLevel(getattr(logging, log_level.upper()))
    file_handler = logging.FileHandler(log_file_path, mode='a')
    formatter = logging.Formatter('%(asctime)s %(levelname)s %(name)s (%(message)s', datefmt='(%d-%m-%Y %I.%M.%S %p)')

    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    log("Log file started.", 'info')









def add_row_to_csv(row_data):
    """
    Adds a new row to the specified CSV file.

    Parameters:
    csv_file_path (str): The path to the CSV file.
    row_data (list): A list containing the row data to be added.
    """
    try:
        csv_file_path = outputCsvReportFilePath
        with open(csv_file_path, mode='a', newline='') as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(row_data)
        log("New row added successfully.","debug")
    except Exception as e:
        log(f"An error occurred: {e}","debug")






def get_report(args):
    folder_id = args[0]
    cr_url = args[1]
    username = args[2]
    apikey = args[3]
    inputoutputFolderPath = args[4]

    log_file_path = inputoutputFolderPath + "\\packagescanner.log"

    log_level = 'debug'
    initialize_logger(log_file_path=log_file_path, log_level=log_level)
    log("get_report fun called with the: folder_id: " + folder_id,log_level)
    # Create sheet in input xlsx
    return get_files_from_folder(folder_id, cr_url, username, apikey, inputoutputFolderPath)



def find_matching_nodes(node, match_rules):
    matched_nodes = []

    for rule in match_rules:
        # Match based on available keys in the rule
        if "commandName" in rule and "packageName" in rule:
            if (node.get("commandName") == rule["commandName"] and
                    node.get("packageName") == rule["packageName"]):
                matched_nodes.append(node)
        elif "packageName" in rule:
            if node.get("packageName") == rule["packageName"]:
                matched_nodes.append(node)
        # No need to handle commandName-only rules since they are invalid by design
    # 🔁 Recursively process children if present
    for group in ["children", "branches"]:
        for child in node.get(group, []):
            matched_nodes.extend(find_matching_nodes(child, match_rules))

    return matched_nodes


# def find_matching_nodes(node, match_rules):
#     matched_nodes = []


#     for rule in match_rules:
#         if (node.get("commandName") == rule["commandName"] and
#                 node.get("packageName") == rule["packageName"]):
#                 matched_nodes.append(node)


#     # 🔁 Recursively process children if present
#     for group in ["children", "branches"]:
#         for child in node.get(group, []):
#             matched_nodes.extend(find_matching_nodes(child, match_rules))


#     return matched_nodes



import openpyxl

def load_input_match_rules(filepath):
    wb = openpyxl.load_workbook(filepath)

    if "Inputs" not in wb.sheetnames:
        raise ValueError(f'Sheet "Inputs" not found in {filepath}')

    sheet = wb["Inputs"]
    match_rules = []

    for row in sheet.iter_rows(min_row=2, values_only=True):
        package_name = str(row[0]).strip() if row[0] is not None else ""
        command_name = str(row[1]).strip() if row[1] is not None else ""

        if package_name and not command_name:
            # Only package name is present
            match_rules.append({
                "packageName": package_name
            })
        elif package_name and command_name:
            # Both are present
            match_rules.append({
                "commandName": command_name,
                "packageName": package_name
            })
        elif command_name and not package_name:
            # Invalid case: command name without package name
            log(f"Skipping row with commandName '{command_name}' but missing packageName", "warning")
            continue  # or raise an error if preferred

    log(', '.join(str(i) for i in match_rules), "debug")
    return match_rules


# def load_input_match_rules(filepath):
#     wb = openpyxl.load_workbook(filepath)

#     # Access the "Updates" sheet instead of the active one
#     if "Data" not in wb.sheetnames:
#         raise ValueError(f'Sheet "Data" not found in {filepath}')

#     sheet = wb["Data"]

#     match_rules = []
#     for row in sheet.iter_rows(min_row=2, values_only=True):
#         match_rules.append({
#             "commandName": str(row[0]).strip(),
#             "packageName": str(row[1]).strip()
#         })
#     log(', '.join(str(i) for i in match_rules), "debug")
#     return match_rules


def get_file_content(file_id, token, cr_url, username, apikey):
    try:
        headers = {
            "X-Authorization": token
        }
        log(f"calling /v2/repository/files/{file_id}/content","debug")
        response = requests.get(f"{cr_url}/v2/repository/files/{file_id}/content", headers=headers)
        if response.status_code == 401:
            log(f"401 Unauthorized error. Re-authenticating for new token","debug")
            token = authenticate(cr_url, username, apikey)
            if not token:
                log("Re-authentication failed.","debug")
                return
            log(f"New token received: {token}","debug")
            headers["X-Authorization"] = str(token)
            log(f"calling /v2/repository/files/{file_id}/content","debug")
            response = requests.get(
                f"{cr_url}/v2/repository/files/{file_id}/content",
                headers=headers
            )
        response.raise_for_status()
        return response.text  # or response.json(), depending on content type
    except requests.RequestException as e:
        log(f"Failed to fetch content for file ID {file_id}: {e}","debug")
        return None


# Auth function to get token
def authenticate(cr_url, username, apikey):
    auth_payload = {
        "username": username,
        "apiKey": apikey
    }
    try:
        response = requests.post(f"{cr_url}/v2/authentication", json=auth_payload)
        response.raise_for_status()
        return response.json().get("token")
    except requests.RequestException as e:
        log(f"Authentication failed: {e}","debug")
        return None



addRowsToExcelCounter = 0


def add_rows_to_excel(filepath, rows, botID):
    """
    Add rows to an Excel sheet. Create the sheet if it doesn't exist.

    Args:
        filepath (str): Path to the Excel file.
        sheet_name (str): Name of the sheet to write to.
        rows (list of list): List of rows to add (each row is a list of cell values).
    """
    global addRowsToExcelCounter
    addRowsToExcelCounter += 1
    log("Going to add rows of " + botID, "debug")
    header = ["Bot Id", "Bot Name", "Bot Path", "Command", "Package"]
    try:
        wb = openpyxl.load_workbook(filepath)
    except FileNotFoundError:
        wb = Workbook()

    # Create sheet if it doesn't exist
    if "Report" in wb.sheetnames:
        sheet = wb["Report"]
    else:
        sheet = wb.create_sheet(title="Report")
        sheet.append(header)

        # Append rows
    for row in rows:
        sheet.append(row)

    # Update BotIDs sheet
    headerBotID = ["Bot Id"]
    if "Bot_IDs" in wb.sheetnames:
        sheet2 = wb["Bot_IDs"]
    else:
        sheet2 = wb.create_sheet(title="Bot_IDs")
        sheet2.append(headerBotID)
    sheet2.append([botID])
    log("Added bot ID: " + botID + " specific rows to the input excel's Report sheet" , "debug")
    wb.save(filepath)


def add_empty_data_message_to_excel(filepath):
    try:
        wb = openpyxl.load_workbook(filepath)
        sheet = wb.create_sheet(title="Report")
        # row = ["No data found for enabled bot commands requiring updates as per the input commands"]
        # sheet.append(row)

        message_lines = [
            "NO MATCHING COMMANDS WERE FOUND. Possible reasons include:",
            "",
            "1. Only ENABLED command lines are being considered.",
            "2. Commands that already have the expected value from the input are excluded."
        ]

        # Styles
        bold_red = Font(bold=True, color="FF0000")  # Red
        bold_black = Font(bold=True, color="000000")  # Black

        # Write each line into the Excel sheet
        for i, line in enumerate(message_lines, start=1):
            cell = sheet.cell(row=i, column=1, value=line)
            cell.font = bold_red if i == 1 else bold_black
        wb.save(filepath)
        log("Added new row to the input excel's Report sheet: " , "debug")
    except FileNotFoundError:
        wb = Workbook()


# Main function to get files
def get_files_from_folder(folder_id, cr_url, username, apikey, inputoutputFolderPath):
    global addRowsToExcelCounter
    token = authenticate(cr_url, username, apikey)
    if not token:
        log("Failed to authenticate. Exiting.","debug")
        return None

    all_files = []
    botIDs = []
    seen_items = set()  # Track IDs to prevent duplicates
    processed_subfolders = set()  # Track processed subfolders
    matched_files = []
    match_rules = load_input_match_rules(inputoutputFolderPath + "\\input.xlsx")

    def fetch_folder(folder_id, token):
        log("inside fetch folder" + folder_id, "debug")
        nonlocal all_files
        page_number = 0

        while True:
            headers = {
                "X-Authorization": str(token)
            }

            payload = {
                "filter": {},
                "sort": [{"field": "id", "direction": "desc"}],
                "page": {
                    "offset": page_number * 100,
                    "length": 100
                }
            }
            log(f"Calling /v2/repository/folders/{folder_id}/list API with token {token}","debug")
            response = requests.post(
                f"{cr_url}/v2/repository/folders/{folder_id}/list",
                headers=headers,
                json=payload
            )

            if response.status_code == 401:
                log("401 unauthorized error. Re-authenticating...","debug")
                token = authenticate(cr_url, username, apikey)

                if not token:
                    log("Re-authentication failed.","debug")
                    return
                log(f"New token generated {token}","debug" )
                headers["X-Authorization"] = str(token)
                log(f"Calling /v2/repository/folders/{folder_id}/list API with token {token}","debug")
                response = requests.post(
                    f"{cr_url}/v2/repository/folders/{folder_id}/list",
                    headers=headers,
                    json=payload
                )

            data = response.json()
            items = data.get("list", [])

            # Stop pagination if no new items are received
            new_items = [item for item in items if item['id'] not in seen_items]
            if not new_items:
                break

            for item in new_items:
                seen_items.add(item['id'])  # Track item ID to avoid duplication

                if item['type'] == 'application/vnd.aa.taskbot':
                    matched_files = []
                    log("Found a taskbot" + item['id'], "debug")
                    all_files.append(item)  # Store full item details
                    content = get_file_content(item['id'], token, cr_url, username, apikey)
                    if not content:
                        continue

                    try:
                        content_json = json.loads(content)
                        log("Analysing taskbot content", "debug")
                        nodes = content_json.get("nodes", [])
                        for node in nodes:
                            all_matches = find_matching_nodes(node, match_rules)
                            for match in all_matches:
                                log("Match nodes found", "debug")
                                matched_files.append([item['id'], item['name'], item['path'], match.get("commandName"),
                                                      match.get("packageName")])


                        # insert each bot specific rows into excel in one go
                        if len(matched_files) > 0:
                            log("matched_files length more than 0. so adding it to the input excel Report sheet", "debug")
                            add_rows_to_excel(
                                inputoutputFolderPath + "\\input.xlsx",
                                matched_files,
                                item['id']
                            )




                    except Exception as e:
                        log(f"JSON parse error for {item.get('name')}: {e}","debug")

                elif item['type'] == 'application/vnd.aa.directory' and item['id'] not in processed_subfolders:
                    processed_subfolders.add(item['id'])  # Mark subfolder as processed
                    fetch_folder(item['id'], token)  # Recursively fetch subfolder contents

            page_number += 1  # Move to the next page for pagination

    fetch_folder(folder_id, token)
    formatted_json = json.dumps({"list": all_files}, indent=4)
    if addRowsToExcelCounter == 0:
        add_empty_data_message_to_excel(inputoutputFolderPath+"\\input.xlsx")
    # print(formatted_json)
    return formatted_json



