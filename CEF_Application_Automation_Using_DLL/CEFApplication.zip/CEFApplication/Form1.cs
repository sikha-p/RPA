﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CefSharp;
using CefSharp.WinForms;
//*****************************************//
// AUTHOR : Sikha P
//          Partner Solution Desk(PSD)
//*****************************************//
namespace CEFApplication
{
    public partial class Form1 : Form
    {
        public ChromiumWebBrowser chromeWebBrowser;

        public Form1()
        {
            InitializeComponent();
            var args = Environment.GetCommandLineArgs();
            string url;
            if (args.Length > 1)
            {
                // The first argument is the executable path, the second is the URL
                url = args[1];

            }
            else
            {
                // Provide a default address if no argument is provided
                url = "https://default-url.com";
            }
            InitializeChromium(url);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.Sizable;
            WindowState = FormWindowState.Maximized;
        }
        private void InitializeChromium(string url)
        {
            CefSettings settings = new CefSettings();
            Cef.Initialize(settings);
            chromeWebBrowser = new ChromiumWebBrowser(url);
            chromeWebBrowser.TitleChanged += OnBrowserTitleChanged;
            chromeWebBrowser.FrameLoadEnd += OnBrowserFrameLoadEnd;
            this.Controls.Add(chromeWebBrowser);
            chromeWebBrowser.Dock = DockStyle.Fill;

        }
        private void OnBrowserTitleChanged(object sender, TitleChangedEventArgs e)
        {
            this.Invoke(new Action(() =>
            {
                this.Text = e.Title;
            }));
        }

        private async void OnBrowserFrameLoadEnd(object sender, FrameLoadEndEventArgs e)
        {
            if (e.Frame.IsMain)
            {
                string iconUrl = await GetFaviconUrl();
                if (!string.IsNullOrEmpty(iconUrl))
                {
                    await SetFormIconAsync(iconUrl);
                }
            }
        }

        private async Task<string> GetFaviconUrl()
        {
            var script = @"
            (function() {
                var links = document.getElementsByTagName('link');
                for (var i = 0; i < links.length; i++) {
                    if (links[i].rel.includes('icon')) {
                        return links[i].href;
                    }
                }
                return '';
            })();";

            var response = await chromeWebBrowser.EvaluateScriptAsync(script);
            if (response.Success && response.Result is string iconUrl)
            {
                return iconUrl;
            }
            return string.Empty;
        }

        private async Task SetFormIconAsync(string iconUrl)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    var iconBytes = await client.GetByteArrayAsync(iconUrl);
                    using (var ms = new System.IO.MemoryStream(iconBytes))
                    {
                        this.Invoke(new Action(() =>
                        {
                            this.Icon = new Icon(ms);
                        }));
                    }
                }
            }
            catch (Exception ex)
            {
                // Log or handle exception if needed
                Console.WriteLine(ex.Message);
            }
        }

       
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Cef.Shutdown();
        }
    }
}
