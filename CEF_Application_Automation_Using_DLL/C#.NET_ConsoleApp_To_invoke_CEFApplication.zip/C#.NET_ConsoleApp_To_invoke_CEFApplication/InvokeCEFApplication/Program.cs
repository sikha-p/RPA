﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
//*****************************************//
// AUTHOR : Sikha P
//          Partner Solution Desk(PSD)
//*****************************************//
namespace InvokeCEFApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            //WAY 1
            ChromeOptions options = new ChromeOptions();
            options.BinaryLocation = @"C:\Users\Sikha.P\..\...\CEFApplication.exe";
            options.AddArgument("--no-sandbox");
            options.AddArgument("--disable-gpu");
            options.AddArgument("--disable-software-rasterizer");
            options.AddArgument("--remote-debugging-port=9222");
            options.AddArgument("https://www.google.com/imghp?hl=en&authuser=0&ogbl");
            using (IWebDriver driver = new ChromeDriver(@"C:\Users\Sikha.P\Downloads\chromedriver_win32 (2)", options))
            {
                driver.Navigate().GoToUrl("https://www.google.com/imghp?hl=en&authuser=0&ogbl");
                var element = driver.FindElement(By.XPath("//*[@id='APjFqb']"));
                element.SendKeys("Automation Anywhere");
            }

            //TRY BELOW ONE IF Above webdriver line is not working

            //using (IWebDriver driver = new ChromeDriver(options))
            //{
            //    driver.Navigate().GoToUrl("https://www.google.com/imghp?hl=en&authuser=0&ogbl");
            //    var element = driver.FindElement(By.XPath("//*[@id='APjFqb']"));
            //    element.SendKeys("Automation Anywhere");
            //}




            //------------------------------------------------------------------------------------------//
            //WAY 2
            StartCefApplication(@"C:\Users\Sikha.P\..\...\CEFApplication.exe");
            //Note : You can start the CEFApplication using command prompt in debug mode instead of using "StartCefApplication".
            //command : go to CEFApplicationFolder in command prompt , then > CEFApplication.exe --remote-debugging-port=9222
            InitializeSelenium();
            PerformAutomation();
        }

        public static Process cefProcess;
        public static IWebDriver driver;
        public static void StartCefApplication(string cefExePath)
        {

            string cefArguments = @"--remote-debugging-port=9222 www.google.com";
            cefProcess = new Process
            {
                StartInfo = new ProcessStartInfo
                {
                    FileName = cefExePath,
                    Arguments = cefArguments,
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    CreateNoWindow = true
                }
            };
            cefProcess.OutputDataReceived += (sender, args) => Console.WriteLine("Output: " + args.Data);
            cefProcess.ErrorDataReceived += (sender, args) => Console.WriteLine("Error: " + args.Data);

            cefProcess.Start();
            cefProcess.BeginOutputReadLine();
            cefProcess.BeginErrorReadLine();

            // Wait longer to ensure CEF is fully started
            Thread.Sleep(10000); // Increase this value if needed

        }

        public static void InitializeSelenium()
        {
            var options = new ChromeOptions();

            //    options.AddArgument("--remote-debugging-port=9222");
            options.DebuggerAddress = "localhost:9222";

            // Add additional options if necessary
            //  driver = new ChromeDriver(@"C:\Users\Sikha.P\Downloads\chromedriver_win32 (2)",options);
            driver = new ChromeDriver(options);
        }

        public static void PerformAutomation()
        {
            driver.Navigate().GoToUrl("https://www.google.com/imghp?hl=en&authuser=0&ogbl");
            IWebElement element = driver.FindElement(By.Name("q"));
            element.SendKeys("CEF with Selenium");
            element.Submit();
        }

        public static void StopCefApplication()
        {
            if (cefProcess != null && !cefProcess.HasExited)
            {
                cefProcess.Kill();
                cefProcess.Dispose();
            }

            driver.Quit();
        }
    }
}
